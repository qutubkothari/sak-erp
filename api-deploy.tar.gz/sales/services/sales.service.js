"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "SalesService", {
    enumerable: true,
    get: function() {
        return SalesService;
    }
});
const _common = require("@nestjs/common");
const _supabasejs = require("@supabase/supabase-js");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
}
let SalesService = class SalesService {
    // ==================== CUSTOMERS ====================
    async getCustomers(req, filters) {
        const { tenantId } = req.user;
        let query = this.supabase.from('customers').select('*').eq('tenant_id', tenantId);
        if (filters?.customer_type) {
            query = query.eq('customer_type', filters.customer_type);
        }
        if (filters?.is_active !== undefined) {
            query = query.eq('is_active', filters.is_active);
        }
        const { data, error } = await query.order('customer_name');
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    async createCustomer(req, customerData) {
        const { tenantId, userId } = req.user;
        const customerCode = await this.generateCustomerCode(req);
        const customer = {
            tenant_id: tenantId,
            customer_code: customerCode,
            customer_name: customerData.customer_name,
            customer_type: customerData.customer_type || 'REGULAR',
            contact_person: customerData.contact_person,
            email: customerData.email,
            phone: customerData.phone,
            mobile: customerData.mobile,
            gst_number: customerData.gst_number,
            pan_number: customerData.pan_number,
            billing_address: customerData.billing_address,
            shipping_address: customerData.shipping_address,
            city: customerData.city,
            state: customerData.state,
            country: customerData.country || 'India',
            pincode: customerData.pincode,
            credit_limit: customerData.credit_limit || 0,
            credit_days: customerData.credit_days || 30,
            is_active: true
        };
        const { data, error } = await this.supabase.from('customers').insert(customer).select().single();
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    async generateCustomerCode(req) {
        const { tenantId } = req.user;
        const { count } = await this.supabase.from('customers').select('*', {
            count: 'exact',
            head: true
        }).eq('tenant_id', tenantId);
        return `CUST-${String((count || 0) + 1).padStart(5, '0')}`;
    }
    // ==================== QUOTATIONS ====================
    async getQuotations(req, filters) {
        const { tenantId } = req.user;
        let query = this.supabase.from('quotations').select(`
        *,
        customers:customer_id(id, customer_code, customer_name, contact_person)
      `).eq('tenant_id', tenantId);
        if (filters?.status) {
            query = query.eq('status', filters.status);
        }
        if (filters?.customer_id) {
            query = query.eq('customer_id', filters.customer_id);
        }
        const { data, error } = await query.order('quotation_date', {
            ascending: false
        });
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    async createQuotation(req, quotationData) {
        const { tenantId, userId } = req.user;
        const quotationNumber = await this.generateQuotationNumber(req);
        // Calculate totals
        let totalAmount = 0;
        const items = quotationData.items.map((item)=>{
            const lineTotal = item.quantity * item.unit_price - (item.discount_amount || 0);
            const taxAmount = lineTotal * (item.tax_percentage || 18) / 100;
            totalAmount += lineTotal + taxAmount;
            return {
                ...item,
                line_total: lineTotal,
                tax_amount: taxAmount
            };
        });
        const discountAmount = quotationData.discount_amount || 0;
        const netAmount = totalAmount - discountAmount;
        const quotation = {
            tenant_id: tenantId,
            quotation_number: quotationNumber,
            customer_id: quotationData.customer_id,
            quotation_date: quotationData.quotation_date || new Date().toISOString().split('T')[0],
            valid_until: quotationData.valid_until,
            status: 'DRAFT',
            total_amount: totalAmount,
            discount_amount: discountAmount,
            net_amount: netAmount,
            payment_terms: quotationData.payment_terms,
            delivery_terms: quotationData.delivery_terms,
            notes: quotationData.notes,
            terms_conditions: quotationData.terms_conditions,
            created_by: userId
        };
        const { data: quotationRecord, error: quotationError } = await this.supabase.from('quotations').insert(quotation).select().single();
        if (quotationError) throw new _common.BadRequestException(quotationError.message);
        // Insert quotation items
        const quotationItems = items.map((item)=>({
                quotation_id: quotationRecord.id,
                item_id: item.item_id,
                item_description: item.item_description,
                quantity: item.quantity,
                unit_price: item.unit_price,
                discount_amount: item.discount_amount || 0,
                tax_percentage: item.tax_percentage || 18,
                tax_amount: item.tax_amount,
                line_total: item.line_total,
                delivery_days: item.delivery_days,
                notes: item.notes
            }));
        const { error: itemsError } = await this.supabase.from('quotation_items').insert(quotationItems);
        if (itemsError) throw new _common.BadRequestException(itemsError.message);
        return quotationRecord;
    }
    async approveQuotation(req, quotationId) {
        const { tenantId, userId } = req.user;
        const { error } = await this.supabase.from('quotations').update({
            status: 'APPROVED',
            approved_by: userId,
            approved_at: new Date().toISOString()
        }).eq('id', quotationId).eq('tenant_id', tenantId);
        if (error) throw new _common.BadRequestException(error.message);
        return {
            message: 'Quotation approved successfully'
        };
    }
    async convertQuotationToSO(req, quotationId) {
        const { tenantId, userId } = req.user;
        // Get quotation with items
        const { data: quotation } = await this.supabase.from('quotations').select('*, quotation_items(*)').eq('id', quotationId).eq('tenant_id', tenantId).single();
        if (!quotation) throw new _common.NotFoundException('Quotation not found');
        if (quotation.status !== 'APPROVED') {
            throw new _common.BadRequestException('Only approved quotations can be converted to sales orders');
        }
        // Create sales order
        const soNumber = await this.generateSONumber(req);
        const salesOrder = {
            tenant_id: tenantId,
            so_number: soNumber,
            quotation_id: quotationId,
            customer_id: quotation.customer_id,
            order_date: new Date().toISOString().split('T')[0],
            status: 'CONFIRMED',
            total_amount: quotation.total_amount,
            discount_amount: quotation.discount_amount,
            net_amount: quotation.net_amount,
            balance_amount: quotation.net_amount,
            payment_terms: quotation.payment_terms,
            delivery_terms: quotation.delivery_terms,
            notes: quotation.notes,
            created_by: userId
        };
        const { data: soRecord, error: soError } = await this.supabase.from('sales_orders').insert(salesOrder).select().single();
        if (soError) throw new _common.BadRequestException(soError.message);
        // Insert sales order items
        const soItems = quotation.quotation_items.map((item)=>({
                sales_order_id: soRecord.id,
                item_id: item.item_id,
                item_description: item.item_description,
                quantity: item.quantity,
                unit_price: item.unit_price,
                discount_amount: item.discount_amount,
                tax_percentage: item.tax_percentage,
                tax_amount: item.tax_amount,
                line_total: item.line_total,
                notes: item.notes
            }));
        const { error: itemsError } = await this.supabase.from('sales_order_items').insert(soItems);
        if (itemsError) throw new _common.BadRequestException(itemsError.message);
        // Update quotation status
        await this.supabase.from('quotations').update({
            status: 'CONVERTED',
            converted_to_so_id: soRecord.id,
            converted_at: new Date().toISOString()
        }).eq('id', quotationId);
        return soRecord;
    }
    async generateQuotationNumber(req) {
        const { tenantId } = req.user;
        const { count } = await this.supabase.from('quotations').select('*', {
            count: 'exact',
            head: true
        }).eq('tenant_id', tenantId);
        return `QT-${String((count || 0) + 1).padStart(6, '0')}`;
    }
    // ==================== SALES ORDERS ====================
    async getSalesOrders(req, filters) {
        const { tenantId } = req.user;
        let query = this.supabase.from('sales_orders').select(`
        *,
        customers:customer_id(id, customer_code, customer_name, contact_person)
      `).eq('tenant_id', tenantId);
        if (filters?.status) {
            query = query.eq('status', filters.status);
        }
        if (filters?.customer_id) {
            query = query.eq('customer_id', filters.customer_id);
        }
        const { data, error } = await query.order('order_date', {
            ascending: false
        });
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    async getSalesOrderById(req, soId) {
        const { tenantId } = req.user;
        const { data, error } = await this.supabase.from('sales_orders').select(`
        *,
        customers:customer_id(id, customer_code, customer_name, contact_person, email, phone),
        sales_order_items(*)
      `).eq('id', soId).eq('tenant_id', tenantId).single();
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    async generateSONumber(req) {
        const { tenantId } = req.user;
        const { count } = await this.supabase.from('sales_orders').select('*', {
            count: 'exact',
            head: true
        }).eq('tenant_id', tenantId);
        return `SO-${String((count || 0) + 1).padStart(6, '0')}`;
    }
    // ==================== DISPATCH ====================
    async createDispatch(req, dispatchData) {
        const { tenantId, userId } = req.user;
        const dnNumber = await this.generateDNNumber(req);
        const dispatch = {
            tenant_id: tenantId,
            dn_number: dnNumber,
            sales_order_id: dispatchData.sales_order_id,
            customer_id: dispatchData.customer_id,
            dispatch_date: dispatchData.dispatch_date || new Date().toISOString().split('T')[0],
            transporter_name: dispatchData.transporter_name,
            vehicle_number: dispatchData.vehicle_number,
            lr_number: dispatchData.lr_number,
            lr_date: dispatchData.lr_date,
            delivery_address: dispatchData.delivery_address,
            notes: dispatchData.notes,
            created_by: userId
        };
        const { data: dispatchRecord, error: dispatchError } = await this.supabase.from('dispatch_notes').insert(dispatch).select().single();
        if (dispatchError) throw new _common.BadRequestException(dispatchError.message);
        // Insert dispatch items with UID assignment
        const dispatchItems = dispatchData.items.map((item)=>({
                dispatch_note_id: dispatchRecord.id,
                sales_order_item_id: item.sales_order_item_id,
                item_id: item.item_id,
                uid: item.uid,
                quantity: item.quantity,
                batch_number: item.batch_number,
                serial_number: item.serial_number,
                notes: item.notes
            }));
        const { error: itemsError } = await this.supabase.from('dispatch_items').insert(dispatchItems);
        if (itemsError) throw new _common.BadRequestException(itemsError.message);
        // Update sales order item dispatched quantities
        for (const item of dispatchData.items){
            await this.supabase.rpc('update_dispatched_quantity', {
                p_so_item_id: item.sales_order_item_id,
                p_quantity: item.quantity
            });
        }
        // Update sales order status
        await this.supabase.from('sales_orders').update({
            status: 'DISPATCHED'
        }).eq('id', dispatchData.sales_order_id);
        // Create warranties for dispatched items
        await this.createWarrantiesForDispatch(req, dispatchRecord.id, dispatchData);
        return dispatchRecord;
    }
    async generateDNNumber(req) {
        const { tenantId } = req.user;
        const { count } = await this.supabase.from('dispatch_notes').select('*', {
            count: 'exact',
            head: true
        }).eq('tenant_id', tenantId);
        return `DN-${String((count || 0) + 1).padStart(6, '0')}`;
    }
    // ==================== WARRANTY ====================
    async createWarrantiesForDispatch(req, dispatchNoteId, dispatchData) {
        const { tenantId } = req.user;
        const { data: dispatchItems } = await this.supabase.from('dispatch_items').select('*').eq('dispatch_note_id', dispatchNoteId);
        if (!dispatchItems || dispatchItems.length === 0) return;
        const warranties = dispatchItems.map((item)=>{
            const warrantyStartDate = dispatchData.dispatch_date || new Date().toISOString().split('T')[0];
            const warrantyDurationMonths = dispatchData.warranty_duration_months || 12;
            const warrantyEndDate = this.calculateWarrantyEndDate(warrantyStartDate, warrantyDurationMonths);
            return {
                tenant_id: tenantId,
                warranty_number: `WR-${item.uid}`,
                uid: item.uid,
                sales_order_id: dispatchData.sales_order_id,
                dispatch_item_id: item.id,
                customer_id: dispatchData.customer_id,
                item_id: item.item_id,
                warranty_start_date: warrantyStartDate,
                warranty_duration_months: warrantyDurationMonths,
                warranty_end_date: warrantyEndDate,
                warranty_type: dispatchData.warranty_type || 'STANDARD',
                covered_components: dispatchData.covered_components,
                warranty_terms: dispatchData.warranty_terms,
                status: 'ACTIVE'
            };
        });
        const { error } = await this.supabase.from('warranties').insert(warranties);
        if (error) throw new _common.BadRequestException(error.message);
    }
    calculateWarrantyEndDate(startDate, durationMonths) {
        const date = new Date(startDate);
        date.setMonth(date.getMonth() + durationMonths);
        return date.toISOString().split('T')[0];
    }
    async getWarranties(req, filters) {
        const { tenantId } = req.user;
        let query = this.supabase.from('warranties').select(`
        *,
        customers:customer_id(customer_code, customer_name, contact_person)
      `).eq('tenant_id', tenantId);
        if (filters?.status) {
            query = query.eq('status', filters.status);
        }
        if (filters?.uid) {
            query = query.eq('uid', filters.uid);
        }
        if (filters?.customer_id) {
            query = query.eq('customer_id', filters.customer_id);
        }
        const { data, error } = await query.order('warranty_start_date', {
            ascending: false
        });
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    async validateWarranty(req, uid) {
        const { tenantId } = req.user;
        const { data: warranty } = await this.supabase.from('warranties').select('*').eq('uid', uid).eq('tenant_id', tenantId).eq('status', 'ACTIVE').single();
        if (!warranty) {
            return {
                valid: false,
                message: 'No active warranty found for this UID'
            };
        }
        const today = new Date().toISOString().split('T')[0];
        if (today > warranty.warranty_end_date) {
            return {
                valid: false,
                message: 'Warranty has expired',
                warranty
            };
        }
        return {
            valid: true,
            message: 'Warranty is active',
            warranty
        };
    }
    async getDispatchNotes(req, filters) {
        const { tenantId } = req.user;
        let query = this.supabase.from('dispatch_notes').select(`
        *,
        sales_orders:sales_order_id(so_number),
        customers:customer_id(customer_code, customer_name)
      `).eq('tenant_id', tenantId);
        if (filters?.sales_order_id) {
            query = query.eq('sales_order_id', filters.sales_order_id);
        }
        const { data, error } = await query.order('dispatch_date', {
            ascending: false
        });
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    constructor(){
        this.supabase = (0, _supabasejs.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
    }
};
SalesService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [])
], SalesService);

//# sourceMappingURL=sales.service.js.map