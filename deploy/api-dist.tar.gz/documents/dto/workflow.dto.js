"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ClientUploadDto () {
        return ClientUploadDto;
    },
    get ForwardDocumentDto () {
        return ForwardDocumentDto;
    },
    get RejectDocumentDto () {
        return RejectDocumentDto;
    },
    get SendToClientDto () {
        return SendToClientDto;
    }
});
let ForwardDocumentDto = class ForwardDocumentDto {
};
let RejectDocumentDto = class RejectDocumentDto {
};
let SendToClientDto = class SendToClientDto {
};
let ClientUploadDto = class ClientUploadDto {
};

//# sourceMappingURL=workflow.dto.js.map