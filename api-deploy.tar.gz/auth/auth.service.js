"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "AuthService", {
    enumerable: true,
    get: function() {
        return AuthService;
    }
});
const _common = require("@nestjs/common");
const _jwt = require("@nestjs/jwt");
const _config = require("@nestjs/config");
const _supabasejs = require("@supabase/supabase-js");
const _bcrypt = /*#__PURE__*/ _interop_require_wildcard(require("bcrypt"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
}
let AuthService = class AuthService {
    async register(dto) {
        // MULTI-TENANT SAAS: Create a NEW tenant for each company registration
        let tenantId = dto.tenantId;
        if (!tenantId) {
            // NEW BEHAVIOR: Create a new tenant for the company
            if (!dto.companyName) {
                throw new Error('Company name is required for new registrations');
            }
            // Check if company/tenant already exists
            const { data: existingTenant } = await this.supabase.from('tenants').select('id, name').eq('name', dto.companyName).eq('is_active', true).maybeSingle();
            if (existingTenant) {
                throw new _common.ConflictException(`Company "${dto.companyName}" already exists. Please contact your administrator for an invitation.`);
            }
            // Create new tenant for this company
            const { data: newTenant, error: tenantError } = await this.supabase.from('tenants').insert({
                name: dto.companyName,
                domain: dto.companyName.toLowerCase().replace(/\s+/g, '-'),
                is_active: true,
                created_at: new Date().toISOString()
            }).select('id').single();
            if (tenantError || !newTenant) {
                throw new Error(`Failed to create tenant: ${tenantError?.message || 'Unknown error'}`);
            }
            tenantId = newTenant.id;
        }
        // Check if user already exists
        const { data: existingUser, error: checkError } = await this.supabase.from('users').select('id').eq('email', dto.email).eq('tenant_id', tenantId).maybeSingle();
        if (existingUser) {
            throw new _common.ConflictException('User with this email already exists');
        }
        // Hash password
        const hashedPassword = await _bcrypt.hash(dto.password, 12);
        // Parse name if provided as single field
        let firstName = dto.firstName;
        let lastName = dto.lastName;
        if (!firstName && dto.name) {
            const nameParts = dto.name.split(' ');
            firstName = nameParts[0];
            lastName = nameParts.slice(1).join(' ') || '';
        }
        // Get default role if not provided
        let roleId = dto.roleId;
        if (!roleId) {
            const { data: defaultRole, error: roleError } = await this.supabase.from('roles').select('id').eq('tenant_id', tenantId).eq('name', 'USER').maybeSingle();
            if (roleError && roleError.code !== 'PGRST116') {
                throw new Error(`Failed to fetch default role: ${roleError.message}`);
            }
            roleId = defaultRole?.id;
        }
        // Create user
        const { data: newUser, error: createError } = await this.supabase.from('users').insert({
            email: dto.email,
            password: hashedPassword,
            first_name: firstName || '',
            last_name: lastName || '',
            tenant_id: tenantId,
            role_id: roleId,
            is_active: true
        }).select('id, email, first_name, last_name, tenant_id').single();
        if (createError) {
            throw new Error(`Failed to create user: ${createError.message}`);
        }
        // Fetch user with role for response
        const { data: userWithRole, error: fetchError } = await this.supabase.from('users').select(`
        id,
        email,
        first_name,
        last_name,
        role:roles (
          id,
          name,
          permissions
        )
      `).eq('id', newUser.id).single();
        if (fetchError) {
            throw new Error(`Failed to fetch user details: ${fetchError.message}`);
        }
        // Transform to match expected format
        const user = {
            id: userWithRole.id,
            email: userWithRole.email,
            firstName: userWithRole.first_name,
            lastName: userWithRole.last_name,
            roles: userWithRole.role ? [
                {
                    role: userWithRole.role
                }
            ] : []
        };
        // Ensure tenantId is set
        if (!tenantId) {
            throw new Error('Tenant ID is required but was not set');
        }
        // Generate tokens
        const tokens = await this.generateTokens(user.id, user.email, tenantId);
        return {
            user,
            ...tokens
        };
    }
    async login(dto) {
        // Get or use default tenant if not provided
        let tenantId = dto.tenantId;
        if (!tenantId) {
            const { data: defaultTenant } = await this.supabase.from('tenants').select('id').eq('is_active', true).limit(1).single();
            tenantId = defaultTenant?.id;
        }
        if (!tenantId) {
            throw new _common.UnauthorizedException('No active tenant found');
        }
        // Find user
        const { data: user, error: userError } = await this.supabase.from('users').select(`
        id,
        email,
        password,
        is_active,
        tenant_id,
        first_name,
        last_name,
        role:roles (
          id,
          name,
          permissions
        )
      `).eq('email', dto.email).eq('tenant_id', tenantId).maybeSingle();
        if (userError || !user) {
            throw new _common.UnauthorizedException('Invalid credentials');
        }
        // Check if user is active
        if (!user.is_active) {
            throw new _common.UnauthorizedException('Account is deactivated');
        }
        // Verify password
        const isPasswordValid = await _bcrypt.compare(dto.password, user.password);
        if (!isPasswordValid) {
            throw new _common.UnauthorizedException('Invalid credentials');
        }
        // Update last login
        await this.supabase.from('users').update({
            last_login_at: new Date().toISOString()
        }).eq('id', user.id);
        // Generate tokens
        const tokens = await this.generateTokens(user.id, user.email, tenantId);
        // Remove password from response and transform to camelCase
        const { password, ...userWithoutPassword } = user;
        const transformedUser = {
            ...userWithoutPassword,
            firstName: user.first_name,
            lastName: user.last_name,
            tenantId: user.tenant_id,
            isActive: user.is_active,
            roles: user.role ? [
                {
                    role: user.role
                }
            ] : []
        };
        return {
            user: transformedUser,
            ...tokens
        };
    }
    async refreshToken(refreshToken) {
        try {
            const payload = this.jwtService.verify(refreshToken, {
                secret: process.env.JWT_REFRESH_SECRET
            });
            const { data: user, error: userError } = await this.supabase.from('users').select('id, email, is_active, tenant_id').eq('id', payload.sub).single();
            if (userError || !user || !user.is_active) {
                throw new _common.UnauthorizedException('Invalid token');
            }
            return this.generateTokens(user.id, user.email, user.tenant_id);
        } catch (error) {
            throw new _common.UnauthorizedException('Invalid refresh token');
        }
    }
    async logout(userId) {
        // Could implement token blacklist here if needed
        return {
            message: 'Logged out successfully'
        };
    }
    async validateUser(userId, tenantId) {
        const { data: user, error: userError } = await this.supabase.from('users').select(`
        id,
        email,
        first_name,
        last_name,
        is_active,
        tenant_id,
        role:roles (
          id,
          name,
          permissions
        )
      `).eq('id', userId).eq('tenant_id', tenantId).eq('is_active', true).maybeSingle();
        if (userError || !user) {
            return null;
        }
        // Transform to camelCase format
        const result = {
            id: user.id,
            email: user.email,
            firstName: user.first_name,
            lastName: user.last_name,
            isActive: user.is_active,
            tenantId: user.tenant_id,
            roles: user.role ? [
                {
                    role: user.role
                }
            ] : []
        };
        return result;
    }
    async generateTokens(userId, email, tenantId) {
        const payload = {
            sub: userId,
            email,
            tenantId
        };
        const [accessToken, refreshToken] = await Promise.all([
            this.jwtService.signAsync(payload, {
                secret: process.env.JWT_SECRET || 'default-secret',
                expiresIn: '24h'
            }),
            this.jwtService.signAsync(payload, {
                secret: process.env.JWT_REFRESH_SECRET || 'default-refresh-secret',
                expiresIn: '30d'
            })
        ]);
        return {
            accessToken,
            refreshToken
        };
    }
    async changePassword(userId, oldPassword, newPassword) {
        const { data: user, error: userError } = await this.supabase.from('users').select('id, password').eq('id', userId).single();
        if (userError || !user) {
            throw new _common.UnauthorizedException('User not found');
        }
        const isPasswordValid = await _bcrypt.compare(oldPassword, user.password);
        if (!isPasswordValid) {
            throw new _common.UnauthorizedException('Current password is incorrect');
        }
        const hashedPassword = await _bcrypt.hash(newPassword, 12);
        const { error: updateError } = await this.supabase.from('users').update({
            password: hashedPassword
        }).eq('id', userId);
        if (updateError) {
            throw new Error(`Failed to update password: ${updateError.message}`);
        }
        return {
            message: 'Password changed successfully'
        };
    }
    async resetPasswordRequest(email, tenantId) {
        const { data: user, error: userError } = await this.supabase.from('users').select('id, email').eq('email', email).eq('tenant_id', tenantId).maybeSingle();
        if (userError || !user) {
            // Don't reveal if user exists
            return {
                message: 'If user exists, password reset email will be sent'
            };
        }
        // Generate reset token (24 hour expiry)
        const resetToken = this.jwtService.sign({
            sub: user.id,
            type: 'reset'
        }, {
            expiresIn: '24h'
        });
        // TODO: Send email with reset link
        // await this.emailService.sendPasswordReset(user.email, resetToken);
        return {
            message: 'If user exists, password reset email will be sent'
        };
    }
    async resetPassword(token, newPassword) {
        try {
            const payload = this.jwtService.verify(token);
            if (payload.type !== 'reset') {
                throw new _common.UnauthorizedException('Invalid reset token');
            }
            const hashedPassword = await _bcrypt.hash(newPassword, 12);
            const { error: updateError } = await this.supabase.from('users').update({
                password: hashedPassword
            }).eq('id', payload.sub);
            if (updateError) {
                throw new Error(`Failed to reset password: ${updateError.message}`);
            }
            return {
                message: 'Password reset successfully'
            };
        } catch (error) {
            throw new _common.UnauthorizedException('Invalid or expired reset token');
        }
    }
    constructor(jwtService, configService){
        this.jwtService = jwtService;
        this.configService = configService;
        const supabaseUrl = this.configService.get('SUPABASE_URL');
        const supabaseKey = this.configService.get('SUPABASE_KEY');
        if (!supabaseUrl || !supabaseKey) {
            throw new Error('SUPABASE_URL and SUPABASE_KEY must be set in environment variables');
        }
        this.supabase = (0, _supabasejs.createClient)(supabaseUrl, supabaseKey);
    }
};
AuthService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _jwt.JwtService === "undefined" ? Object : _jwt.JwtService,
        typeof _config.ConfigService === "undefined" ? Object : _config.ConfigService
    ])
], AuthService);

//# sourceMappingURL=auth.service.js.map