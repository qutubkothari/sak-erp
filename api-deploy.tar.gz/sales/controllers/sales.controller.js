"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "SalesController", {
    enumerable: true,
    get: function() {
        return SalesController;
    }
});
const _common = require("@nestjs/common");
const _salesservice = require("../services/sales.service");
const _jwtauthguard = require("../../auth/guards/jwt-auth.guard");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let SalesController = class SalesController {
    // ==================== CUSTOMERS ====================
    async getCustomers(req, filters) {
        return this.salesService.getCustomers(req, filters);
    }
    async createCustomer(req, customerData) {
        return this.salesService.createCustomer(req, customerData);
    }
    // ==================== QUOTATIONS ====================
    async getQuotations(req, filters) {
        return this.salesService.getQuotations(req, filters);
    }
    async createQuotation(req, quotationData) {
        return this.salesService.createQuotation(req, quotationData);
    }
    async approveQuotation(req, quotationId) {
        return this.salesService.approveQuotation(req, quotationId);
    }
    async convertQuotationToSO(req, quotationId) {
        return this.salesService.convertQuotationToSO(req, quotationId);
    }
    // ==================== SALES ORDERS ====================
    async getSalesOrders(req, filters) {
        return this.salesService.getSalesOrders(req, filters);
    }
    async getSalesOrderById(req, soId) {
        return this.salesService.getSalesOrderById(req, soId);
    }
    // ==================== DISPATCH ====================
    async getDispatchNotes(req, filters) {
        return this.salesService.getDispatchNotes(req, filters);
    }
    async createDispatch(req, dispatchData) {
        return this.salesService.createDispatch(req, dispatchData);
    }
    // ==================== WARRANTY ====================
    async getWarranties(req, filters) {
        return this.salesService.getWarranties(req, filters);
    }
    async validateWarranty(req, uid) {
        return this.salesService.validateWarranty(req, uid);
    }
    constructor(salesService){
        this.salesService = salesService;
    }
};
_ts_decorate([
    (0, _common.Get)('customers'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Query)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], SalesController.prototype, "getCustomers", null);
_ts_decorate([
    (0, _common.Post)('customers'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], SalesController.prototype, "createCustomer", null);
_ts_decorate([
    (0, _common.Get)('quotations'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Query)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], SalesController.prototype, "getQuotations", null);
_ts_decorate([
    (0, _common.Post)('quotations'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], SalesController.prototype, "createQuotation", null);
_ts_decorate([
    (0, _common.Put)('quotations/:id/approve'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], SalesController.prototype, "approveQuotation", null);
_ts_decorate([
    (0, _common.Post)('quotations/:id/convert-to-so'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], SalesController.prototype, "convertQuotationToSO", null);
_ts_decorate([
    (0, _common.Get)('orders'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Query)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], SalesController.prototype, "getSalesOrders", null);
_ts_decorate([
    (0, _common.Get)('orders/:id'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], SalesController.prototype, "getSalesOrderById", null);
_ts_decorate([
    (0, _common.Get)('dispatch'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Query)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], SalesController.prototype, "getDispatchNotes", null);
_ts_decorate([
    (0, _common.Post)('dispatch'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], SalesController.prototype, "createDispatch", null);
_ts_decorate([
    (0, _common.Get)('warranties'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Query)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], SalesController.prototype, "getWarranties", null);
_ts_decorate([
    (0, _common.Get)('warranties/validate/:uid'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('uid')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], SalesController.prototype, "validateWarranty", null);
SalesController = _ts_decorate([
    (0, _common.Controller)('sales'),
    (0, _common.UseGuards)(_jwtauthguard.JwtAuthGuard),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _salesservice.SalesService === "undefined" ? Object : _salesservice.SalesService
    ])
], SalesController);

//# sourceMappingURL=sales.controller.js.map