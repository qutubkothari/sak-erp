"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DocumentCategoriesService", {
    enumerable: true,
    get: function() {
        return DocumentCategoriesService;
    }
});
const _common = require("@nestjs/common");
const _supabasejs = require("@supabase/supabase-js");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
let DocumentCategoriesService = class DocumentCategoriesService {
    async create(req, createDto) {
        const tenantId = req.user.tenantId;
        const { data, error } = await this.supabase.from('document_categories').insert([
            {
                ...createDto,
                tenant_id: tenantId
            }
        ]).select().single();
        if (error) throw new Error(error.message);
        return data;
    }
    async findAll(req) {
        const tenantId = req.user.tenantId;
        const { data, error } = await this.supabase.from('document_categories').select('*').eq('tenant_id', tenantId).eq('is_active', true).order('name');
        if (error) throw new Error(error.message);
        return data;
    }
    async findOne(req, id) {
        const tenantId = req.user.tenantId;
        const { data, error } = await this.supabase.from('document_categories').select('*').eq('tenant_id', tenantId).eq('id', id).single();
        if (error) throw new Error(error.message);
        return data;
    }
    async update(req, id, updateDto) {
        const tenantId = req.user.tenantId;
        const { data, error } = await this.supabase.from('document_categories').update(updateDto).eq('tenant_id', tenantId).eq('id', id).select().single();
        if (error) throw new Error(error.message);
        return data;
    }
    async delete(req, id) {
        const tenantId = req.user.tenantId;
        const { error } = await this.supabase.from('document_categories').delete().eq('tenant_id', tenantId).eq('id', id);
        if (error) throw new Error(error.message);
        return {
            message: 'Category deleted successfully'
        };
    }
    constructor(){
        this.supabase = (0, _supabasejs.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
    }
};
DocumentCategoriesService = _ts_decorate([
    (0, _common.Injectable)()
], DocumentCategoriesService);

//# sourceMappingURL=document-categories.service.js.map