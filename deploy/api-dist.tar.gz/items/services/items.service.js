"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ItemsService", {
    enumerable: true,
    get: function() {
        return ItemsService;
    }
});
const _common = require("@nestjs/common");
const _supabasejs = require("@supabase/supabase-js");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
let ItemsService = class ItemsService {
    normalizeNumber(value, type = 'float') {
        if (value === undefined || value === null || value === '') {
            return null;
        }
        const raw = typeof value === 'string' ? value.trim() : String(value);
        // Handle common Excel formats: commas, currency symbols, spaces
        const cleaned = raw.replace(/,/g, '').replace(/[^0-9.\-]/g, '');
        if (!cleaned) {
            return null;
        }
        const parsed = type === 'int' ? parseInt(cleaned, 10) : parseFloat(cleaned);
        return Number.isNaN(parsed) ? null : parsed;
    }
    normalizeAndValidateHsn(value, options) {
        if (value === undefined || value === null || value === '') {
            if (options.required) {
                throw new _common.BadRequestException('HSN code is required');
            }
            return null;
        }
        const hsnStr = String(value).trim();
        if (!/^\d{4}$|^\d{6}$|^\d{8}$/.test(hsnStr)) {
            throw new _common.BadRequestException('Invalid HSN code. Must be 4, 6, or 8 digits.');
        }
        return hsnStr;
    }
    normalizeUidFields(itemData) {
        const rawUidTracking = itemData.uid_tracking ?? itemData.uidTracking;
        const rawUidStrategy = itemData.uid_strategy ?? itemData.uidStrategy;
        const rawBatchUom = itemData.batch_uom ?? itemData.batchUom;
        const rawBatchQuantity = itemData.batch_quantity ?? itemData.batchQuantity;
        const anyProvided = rawUidTracking !== undefined || rawUidStrategy !== undefined || rawBatchUom !== undefined || rawBatchQuantity !== undefined;
        if (!anyProvided) {
            return {};
        }
        // If tracking is explicitly disabled, force NONE strategy.
        if (rawUidTracking === false) {
            return {
                uid_tracking: false,
                uid_strategy: 'NONE',
                batch_uom: null,
                batch_quantity: null
            };
        }
        const strategy = rawUidStrategy || 'SERIALIZED';
        if (strategy !== 'SERIALIZED' && strategy !== 'BATCHED' && strategy !== 'NONE') {
            throw new _common.BadRequestException('Invalid UID strategy. Must be SERIALIZED, BATCHED, or NONE.');
        }
        if (strategy === 'NONE') {
            return {
                uid_tracking: false,
                uid_strategy: 'NONE',
                batch_uom: null,
                batch_quantity: null
            };
        }
        if (strategy === 'BATCHED') {
            const batchUom = rawBatchUom ? String(rawBatchUom).trim() : '';
            const batchQty = this.normalizeNumber(rawBatchQuantity);
            if (!batchUom) {
                throw new _common.BadRequestException('For BATCHED UID strategy, batch_uom is required.');
            }
            if (!batchQty || batchQty <= 0) {
                throw new _common.BadRequestException('For BATCHED UID strategy, batch_quantity must be > 0.');
            }
            return {
                uid_tracking: true,
                uid_strategy: 'BATCHED',
                batch_uom: batchUom,
                batch_quantity: batchQty
            };
        }
        // SERIALIZED
        return {
            uid_tracking: true,
            uid_strategy: 'SERIALIZED',
            batch_uom: null,
            batch_quantity: null
        };
    }
    async findAll(tenantId, search, includeInactive) {
        let query = this.supabase.from('items').select('*').eq('tenant_id', tenantId).order('name', {
            ascending: true
        });
        // Only filter by is_active if we're not including inactive items
        if (!includeInactive) {
            query = query.eq('is_active', true);
        }
        if (search) {
            query = query.or(`code.ilike.%${search}%,name.ilike.%${search}%,description.ilike.%${search}%`);
        }
        const { data, error } = await query;
        if (error) {
            console.error('[ItemsService] Query error:', error);
            throw new Error(`Failed to fetch items: ${error.message}`);
        }
        // Fetch stock totals using Supabase REST API
        if (data && data.length > 0) {
            // IMPORTANT: Do NOT use `.in('item_id', itemIds)` here.
            // With hundreds of item IDs it produces an enormous URL and can fail at the HTTP layer
            // (we observed undici HeadersOverflowError / "TypeError: fetch failed").
            // Instead, fetch only rows with positive stock for the tenant and aggregate in-memory.
            const { data: stockData, error: stockError } = await this.supabase.from('stock_entries').select('item_id, available_quantity').eq('tenant_id', tenantId).gt('available_quantity', 0);
            if (stockError || !stockData) {
                console.error('[ItemsService] Stock query error:', stockError);
                return data.map((item)=>({
                        ...item,
                        total_stock: 0
                    }));
            }
            // Sum up stock per item
            const stockTotals = (stockData || []).reduce((acc, entry)=>{
                acc[entry.item_id] = (acc[entry.item_id] || 0) + (parseFloat(entry.available_quantity) || 0);
                return acc;
            }, {});
            // Add total_stock to each item
            return data.map((item)=>({
                    ...item,
                    total_stock: stockTotals[item.id] || 0
                }));
        }
        return data || [];
    }
    async search(tenantId, query) {
        if (!query || query.trim().length === 0) {
            return [];
        }
        const searchTerm = query.trim();
        const { data, error } = await this.supabase.from('items').select('id, code, name, description, uom, category, standard_cost, selling_price').eq('tenant_id', tenantId).eq('is_active', true).or(`code.ilike.%${searchTerm}%,name.ilike.%${searchTerm}%,description.ilike.%${searchTerm}%`).limit(20).order('name', {
            ascending: true
        });
        if (error) {
            throw new Error(`Search failed: ${error.message}`);
        }
        return data || [];
    }
    async findOne(tenantId, id) {
        const { data, error } = await this.supabase.from('items').select('*').eq('tenant_id', tenantId).eq('id', id).single();
        if (error) {
            throw new Error(`Failed to fetch item: ${error.message}`);
        }
        return data;
    }
    async create(tenantId, itemData) {
        console.log('[ItemsService.create] Creating item with data:', JSON.stringify(itemData, null, 2));
        // HSN is required unless this is a variant (variants can inherit empty HSN)
        const isVariant = itemData.is_variant === true;
        console.log('[ItemsService.create] Is variant:', isVariant);
        const validatedHsn = this.normalizeAndValidateHsn(itemData.hsnCode ?? itemData.hsn_code, {
            required: !isVariant
        });
        console.log('[ItemsService.create] Validated HSN:', validatedHsn);
        const uidFields = this.normalizeUidFields(itemData);
        const drawingRequired = itemData.drawing_required ?? itemData.drawingRequired;
        if (drawingRequired !== undefined && drawingRequired !== 'OPTIONAL' && drawingRequired !== 'COMPULSORY' && drawingRequired !== 'NOT_REQUIRED') {
            throw new _common.BadRequestException('Invalid drawing_required. Must be OPTIONAL, COMPULSORY, or NOT_REQUIRED.');
        }
        const standardCost = this.normalizeNumber(itemData.standard_cost ?? itemData.standardCost);
        const sellingPrice = this.normalizeNumber(itemData.selling_price ?? itemData.sellingPrice);
        const reorderLevel = this.normalizeNumber(itemData.reorder_level ?? itemData.reorderLevel, 'int');
        const reorderQuantity = this.normalizeNumber(itemData.reorder_quantity ?? itemData.reorderQuantity, 'int');
        const leadTimeDays = this.normalizeNumber(itemData.lead_time_days ?? itemData.leadTimeDays, 'int');
        const { data, error } = await this.supabase.from('items').insert({
            tenant_id: tenantId,
            code: itemData.code,
            name: itemData.name,
            description: itemData.description,
            category: itemData.category,
            uom: itemData.uom,
            reorder_level: reorderLevel,
            min_stock: itemData.minStock,
            max_stock: itemData.maxStock,
            standard_cost: standardCost,
            selling_price: sellingPrice,
            reorder_quantity: reorderQuantity,
            lead_time_days: leadTimeDays,
            hsn_code: validatedHsn,
            drawing_required: drawingRequired,
            parent_item_id: itemData.parent_item_id || null,
            is_variant: itemData.is_variant || false,
            is_default_variant: itemData.is_default_variant || false,
            variant_name: itemData.variant_name || null,
            ...uidFields,
            is_active: true,
            metadata: itemData.metadata || {}
        }).select().single();
        console.log('[ItemsService.create] Database result:', {
            data,
            error
        });
        if (error) {
            console.error('[ItemsService.create] Database error:', error);
            // Check for duplicate key constraint violation
            if (error.code === '23505' && error.message.includes('items_code_key')) {
                throw new Error(`Item with code '${itemData.code}' already exists`);
            }
            throw new Error(`Failed to create item: ${error.message}`);
        }
        console.log('[ItemsService.create] Successfully created item:', data?.id);
        return data;
    }
    async bulkCreate(tenantId, items) {
        const results = {
            success: 0,
            failed: 0,
            errors: []
        };
        // Map category names from user's format to database format
        const categoryMap = {
            'Services': 'SERVICE',
            'Injection Moulding': 'COMPONENT',
            'Machining': 'COMPONENT',
            'Raw Material': 'RAW_MATERIAL',
            'Products': 'FINISHED_GOODS',
            'Sub Assemblies': 'SUBASSEMBLY',
            'Consumables': 'CONSUMABLE',
            'Packing Material': 'PACKING_MATERIAL',
            'Spare Parts': 'SPARE_PART'
        };
        for(let i = 0; i < items.length; i++){
            const item = items[i];
            try {
                // Map Excel column names to database fields - support multiple formats
                const rawCode = item['Item Code'] || item.code || item.Code || item.CODE || item['Item code'] || item['item code'];
                const rawName = item['Item Name'] || item.name || item.Name || item.NAME || item['Item name'] || item['item name'];
                const rawCategory = item['Item Group'] || item.category || item.Category || item.CATEGORY || item['Item group'] || item['item group'];
                const rawUom = item['Default Unit of Measure'] || item.uom || item.UOM || item.unit || item.Unit || item['Unit of Measure'];
                const rawHsn = item['HSN/SAC'] || item.hsn || item.HSN || item.hsn_code || item['HSN Code'];
                const rawStandardCost = item.standard_cost || item.StandardCost || item['Standard Cost'] || item['Standard cost'] || item.cost || item.Cost || item['Unit Cost'] || item['Unit cost'] || item['Rate'] || item.rate;
                const rawSellingPrice = item.selling_price || item.SellingPrice || item['Selling Price'] || item['Selling price'] || item.price || item.Price || item['Unit Price'] || item['Unit price'] || item['MRP'] || item.mrp;
                const validatedHsn = this.normalizeAndValidateHsn(rawHsn, {
                    required: true
                });
                // Map category to database format
                let mappedCategory = categoryMap[rawCategory] || rawCategory || 'RAW_MATERIAL';
                // If still not a valid category, default to RAW_MATERIAL
                if (![
                    'RAW_MATERIAL',
                    'COMPONENT',
                    'SUBASSEMBLY',
                    'FINISHED_GOODS',
                    'CONSUMABLE',
                    'PACKING_MATERIAL',
                    'SPARE_PART',
                    'SERVICE'
                ].includes(mappedCategory)) {
                    mappedCategory = 'RAW_MATERIAL';
                }
                const itemData = {
                    code: rawCode,
                    name: rawName || rawCode,
                    description: item.description || item.Description || item.DESCRIPTION || '',
                    category: mappedCategory,
                    uom: rawUom || 'PCS',
                    standard_cost: this.normalizeNumber(rawStandardCost),
                    selling_price: this.normalizeNumber(rawSellingPrice),
                    reorder_level: this.normalizeNumber(item.reorder_level || item.ReorderLevel || item['Reorder Level'] || item['Reorder level'] || item.min_qty, 'int'),
                    reorder_quantity: this.normalizeNumber(item.reorder_quantity || item.ReorderQuantity || item['Reorder Quantity'] || item['Reorder quantity'] || item.order_qty, 'int'),
                    lead_time_days: this.normalizeNumber(item.lead_time_days || item.LeadTimeDays || item['Lead Time'] || item['Lead time'] || item.lead_time, 'int')
                };
                const { error } = await this.supabase.from('items').insert({
                    tenant_id: tenantId,
                    code: itemData.code,
                    name: itemData.name,
                    description: itemData.description,
                    category: itemData.category,
                    uom: itemData.uom,
                    standard_cost: itemData.standard_cost,
                    selling_price: itemData.selling_price,
                    reorder_level: itemData.reorder_level,
                    reorder_quantity: itemData.reorder_quantity,
                    lead_time_days: itemData.lead_time_days,
                    hsn_code: validatedHsn,
                    is_active: true,
                    metadata: {
                        item_group: rawCategory || null
                    }
                });
                if (error) {
                    results.failed++;
                    results.errors.push({
                        row: i + 1,
                        item: itemData.name || itemData.code,
                        error: error.message
                    });
                } else {
                    results.success++;
                }
            } catch (err) {
                results.failed++;
                results.errors.push({
                    row: i + 1,
                    item: item.name || item.code || 'Unknown',
                    error: err.message
                });
            }
        }
        return results;
    }
    async update(tenantId, id, itemData) {
        const hsnProvided = itemData.hsnCode !== undefined || itemData.hsn_code !== undefined;
        const validatedHsn = hsnProvided ? this.normalizeAndValidateHsn(itemData.hsnCode ?? itemData.hsn_code, {
            required: true
        }) : null;
        const updateData = {
            updated_at: new Date().toISOString()
        };
        // Only update fields that are provided
        if (itemData.code !== undefined) updateData.code = itemData.code;
        if (itemData.name !== undefined) updateData.name = itemData.name;
        if (itemData.description !== undefined) updateData.description = itemData.description;
        if (itemData.category !== undefined) updateData.category = itemData.category;
        if (itemData.uom !== undefined) updateData.uom = itemData.uom;
        const standardCostProvided = itemData.standard_cost !== undefined || itemData.standardCost !== undefined;
        const sellingPriceProvided = itemData.selling_price !== undefined || itemData.sellingPrice !== undefined;
        const reorderLevelProvided = itemData.reorder_level !== undefined || itemData.reorderLevel !== undefined;
        const reorderQtyProvided = itemData.reorder_quantity !== undefined || itemData.reorderQuantity !== undefined;
        const leadTimeProvided = itemData.lead_time_days !== undefined || itemData.leadTimeDays !== undefined;
        if (standardCostProvided) {
            updateData.standard_cost = this.normalizeNumber(itemData.standard_cost ?? itemData.standardCost);
        }
        if (sellingPriceProvided) {
            updateData.selling_price = this.normalizeNumber(itemData.selling_price ?? itemData.sellingPrice);
        }
        if (reorderLevelProvided) {
            updateData.reorder_level = this.normalizeNumber(itemData.reorder_level ?? itemData.reorderLevel, 'int');
        }
        if (reorderQtyProvided) {
            updateData.reorder_quantity = this.normalizeNumber(itemData.reorder_quantity ?? itemData.reorderQuantity, 'int');
        }
        if (leadTimeProvided) {
            updateData.lead_time_days = this.normalizeNumber(itemData.lead_time_days ?? itemData.leadTimeDays, 'int');
        }
        if (itemData.minStock !== undefined) updateData.min_stock = itemData.minStock;
        if (itemData.maxStock !== undefined) updateData.max_stock = itemData.maxStock;
        if (itemData.metadata !== undefined) updateData.metadata = itemData.metadata;
        if (validatedHsn !== null) updateData.hsn_code = validatedHsn;
        if (itemData.is_active !== undefined) updateData.is_active = itemData.is_active;
        // Variant fields
        if (itemData.parent_item_id !== undefined) updateData.parent_item_id = itemData.parent_item_id || null;
        if (itemData.is_variant !== undefined) updateData.is_variant = itemData.is_variant;
        if (itemData.is_default_variant !== undefined) updateData.is_default_variant = itemData.is_default_variant;
        if (itemData.variant_name !== undefined) updateData.variant_name = itemData.variant_name || null;
        const drawingRequired = itemData.drawing_required ?? itemData.drawingRequired;
        if (drawingRequired !== undefined) {
            if (drawingRequired !== 'OPTIONAL' && drawingRequired !== 'COMPULSORY' && drawingRequired !== 'NOT_REQUIRED') {
                throw new _common.BadRequestException('Invalid drawing_required. Must be OPTIONAL, COMPULSORY, or NOT_REQUIRED.');
            }
            updateData.drawing_required = drawingRequired;
        }
        const uidFields = this.normalizeUidFields(itemData);
        Object.assign(updateData, uidFields);
        const { data, error } = await this.supabase.from('items').update(updateData).eq('tenant_id', tenantId).eq('id', id).select().single();
        if (error) {
            throw new Error(`Failed to update item: ${error.message}`);
        }
        return data;
    }
    async delete(tenantId, id) {
        // Soft delete
        const { error } = await this.supabase.from('items').update({
            is_active: false
        }).eq('tenant_id', tenantId).eq('id', id);
        if (error) {
            throw new Error(`Failed to delete item: ${error.message}`);
        }
        return {
            message: 'Item deleted successfully'
        };
    }
    // Drawing/Document Management
    async getDrawings(tenantId, itemId) {
        const { data, error } = await this.supabase.from('item_drawings').select('*').eq('tenant_id', tenantId).eq('item_id', itemId).order('version', {
            ascending: false
        });
        if (error) {
            throw new Error(`Failed to fetch drawings: ${error.message}`);
        }
        return data || [];
    }
    async uploadDrawing(tenantId, userId, itemId, drawingData) {
        const documentId = (drawingData?.documentId || drawingData?.document_id || '').toString().trim();
        let resolvedFileName = drawingData?.fileName;
        let resolvedFileUrl = drawingData?.fileUrl;
        let resolvedFileType = drawingData?.fileType;
        let resolvedFileSize = drawingData?.fileSize;
        if (documentId) {
            const { data: doc, error: docError } = await this.supabase.from('documents').select('id, file_url, file_name, file_type, file_size, title').eq('tenant_id', tenantId).eq('id', documentId).single();
            if (docError || !doc) {
                throw new Error(`Failed to link drawing from document: ${docError?.message || 'Document not found'}`);
            }
            resolvedFileUrl = doc.file_url;
            resolvedFileName = doc.file_name || doc.title || 'drawing';
            resolvedFileType = doc.file_type;
            resolvedFileSize = doc.file_size;
        }
        if (!resolvedFileUrl) {
            throw new Error('Missing drawing fileUrl');
        }
        // Get current max version for this item
        const { data: existingDrawings } = await this.supabase.from('item_drawings').select('version').eq('tenant_id', tenantId).eq('item_id', itemId).order('version', {
            ascending: false
        }).limit(1);
        const nextVersion = existingDrawings && existingDrawings.length > 0 ? existingDrawings[0].version + 1 : 1;
        const baseInsert = {
            tenant_id: tenantId,
            item_id: itemId,
            file_name: resolvedFileName,
            file_url: resolvedFileUrl,
            file_type: resolvedFileType,
            file_size: resolvedFileSize,
            version: nextVersion,
            revision_notes: drawingData.revisionNotes,
            is_active: true,
            uploaded_by: userId
        };
        const tryInsert = async (payload)=>{
            return this.supabase.from('item_drawings').insert(payload).select().single();
        };
        // Prefer to persist the source document reference when available, but tolerate schema drift.
        let insertResult = documentId ? await tryInsert({
            ...baseInsert,
            document_id: documentId
        }) : await tryInsert(baseInsert);
        if (insertResult.error && documentId) {
            const message = String(insertResult.error?.message || '').toLowerCase();
            if (message.includes('document_id') && (message.includes('column') || message.includes('does not exist'))) {
                insertResult = await tryInsert(baseInsert);
            }
        }
        const data = insertResult.data;
        const error = insertResult.error;
        if (error) {
            throw new Error(`Failed to upload drawing: ${error.message}`);
        }
        // Ensure only one active drawing per item (latest by default)
        const { error: deactivateError } = await this.supabase.from('item_drawings').update({
            is_active: false
        }).eq('tenant_id', tenantId).eq('item_id', itemId).neq('id', data.id);
        if (deactivateError) {
            throw new Error(`Failed to finalize drawing upload: ${deactivateError.message}`);
        }
        return data;
    }
    async updateDrawing(tenantId, itemId, drawingId, drawingData) {
        const { data, error } = await this.supabase.from('item_drawings').update({
            revision_notes: drawingData.revisionNotes,
            is_active: drawingData.isActive,
            updated_at: new Date().toISOString()
        }).eq('tenant_id', tenantId).eq('item_id', itemId).eq('id', drawingId).select().single();
        if (error) {
            throw new Error(`Failed to update drawing: ${error.message}`);
        }
        // If activated, deactivate all others to keep exactly one ACTIVE drawing
        if (drawingData.isActive === true) {
            const { error: deactivateError } = await this.supabase.from('item_drawings').update({
                is_active: false
            }).eq('tenant_id', tenantId).eq('item_id', itemId).neq('id', drawingId);
            if (deactivateError) {
                throw new Error(`Failed to activate drawing: ${deactivateError.message}`);
            }
        }
        return data;
    }
    async deleteDrawing(tenantId, itemId, drawingId) {
        const { error } = await this.supabase.from('item_drawings').update({
            is_active: false
        }).eq('tenant_id', tenantId).eq('item_id', itemId).eq('id', drawingId);
        if (error) {
            throw new Error(`Failed to delete drawing: ${error.message}`);
        }
        return {
            message: 'Drawing deleted successfully'
        };
    }
    // Item-Vendor Relationship Methods
    async getItemVendors(tenantId, itemId) {
        const { data, error } = await this.supabase.from('item_vendors').select(`
        *,
        vendor:vendors(id, code, name, contact_person, email, phone)
      `).eq('item_id', itemId).eq('is_active', true).order('priority', {
            ascending: true
        });
        if (error) {
            throw new Error(`Failed to fetch item vendors: ${error.message}`);
        }
        return data || [];
    }
    async getPreferredVendor(itemId) {
        const { data, error } = await this.supabase.rpc('get_preferred_vendor', {
            p_item_id: itemId
        });
        if (error) {
            throw new Error(`Failed to fetch preferred vendor: ${error.message}`);
        }
        return data?.[0] || null;
    }
    async addItemVendor(tenantId, userId, itemId, body) {
        const { data, error } = await this.supabase.from('item_vendors').insert({
            item_id: itemId,
            vendor_id: body.vendor_id,
            priority: body.priority || 1,
            unit_price: this.normalizeNumber(body.unit_price),
            lead_time_days: this.normalizeNumber(body.lead_time_days, 'int'),
            vendor_item_code: body.vendor_item_code || null,
            minimum_order_quantity: this.normalizeNumber(body.minimum_order_quantity),
            payment_terms: body.payment_terms || null,
            notes: body.notes || null,
            created_by: userId
        }).select().single();
        if (error) {
            throw new Error(`Failed to add vendor: ${error.message}`);
        }
        return data;
    }
    async updateItemVendor(tenantId, userId, itemId, vendorId, body) {
        const { data, error } = await this.supabase.from('item_vendors').update({
            priority: body.priority,
            unit_price: this.normalizeNumber(body.unit_price),
            lead_time_days: this.normalizeNumber(body.lead_time_days, 'int'),
            vendor_item_code: body.vendor_item_code,
            minimum_order_quantity: this.normalizeNumber(body.minimum_order_quantity),
            payment_terms: body.payment_terms,
            notes: body.notes,
            is_active: body.is_active !== undefined ? body.is_active : true,
            updated_by: userId
        }).eq('item_id', itemId).eq('vendor_id', vendorId).select().single();
        if (error) {
            throw new Error(`Failed to update vendor: ${error.message}`);
        }
        return data;
    }
    async deleteItemVendor(tenantId, itemId, vendorId) {
        const { error } = await this.supabase.from('item_vendors').update({
            is_active: false
        }).eq('item_id', itemId).eq('vendor_id', vendorId);
        if (error) {
            throw new Error(`Failed to remove vendor: ${error.message}`);
        }
        return {
            message: 'Vendor removed successfully'
        };
    }
    async getPurchasePriceHistory(itemId, vendorId) {
        const { data, error } = await this.supabase.rpc('get_purchase_price_history', {
            p_item_id: itemId,
            p_vendor_id: vendorId
        });
        if (error) {
            throw new Error(`Failed to get purchase price history: ${error.message}`);
        }
        return data || [];
    }
    async getItemStock(itemId, tenantId) {
        const { data, error } = await this.supabase.rpc('get_item_stock_summary', {
            p_item_id: itemId,
            p_tenant_id: tenantId
        });
        if (error) {
            throw new Error(`Failed to get item stock: ${error.message}`);
        }
        return data && data.length > 0 ? data[0] : {
            total_quantity: 0,
            available_quantity: 0,
            allocated_quantity: 0
        };
    }
    // Get all variants of an item
    async getItemVariants(tenantId, itemId) {
        console.log('[getItemVariants] Fetching variants for item:', itemId, 'tenant:', tenantId);
        const { data, error } = await this.supabase.from('items').select('id, code, name, variant_name, is_default_variant, category, uom, hsn_code').eq('tenant_id', tenantId).eq('parent_item_id', itemId).eq('is_variant', true).eq('is_active', true).order('is_default_variant', {
            ascending: false
        }).order('variant_name', {
            ascending: true
        });
        console.log('[getItemVariants] Query result:', {
            data,
            error,
            count: data?.length
        });
        if (error) {
            throw new Error(`Failed to get item variants: ${error.message}`);
        }
        return data || [];
    }
    // Get default variant for an item
    async getDefaultVariant(tenantId, itemId) {
        const { data, error } = await this.supabase.from('items').select('*').eq('tenant_id', tenantId).eq('parent_item_id', itemId).eq('is_variant', true).eq('is_default_variant', true).eq('is_active', true).maybeSingle();
        if (error) {
            throw new Error(`Failed to get default variant: ${error.message}`);
        }
        return data;
    }
    constructor(){
        this.supabase = (0, _supabasejs.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
    }
};
ItemsService = _ts_decorate([
    (0, _common.Injectable)()
], ItemsService);

//# sourceMappingURL=items.service.js.map