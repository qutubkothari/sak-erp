// Helper file to make email services compile quickly
// TODO: Replace these with proper Prisma queries later
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});

//# sourceMappingURL=email.types.js.map