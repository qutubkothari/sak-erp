"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "UidController", {
    enumerable: true,
    get: function() {
        return UidController;
    }
});
const _common = require("@nestjs/common");
const _swagger = require("@nestjs/swagger");
const _uidservice = require("./uid.service");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let UidController = class UidController {
    async getUidHistory(uid) {
        return this.uidService.getUidHistory(uid);
    }
    async validateUid(uid) {
        const isValid = this.uidService.validateUid(uid);
        return {
            uid,
            isValid,
            message: isValid ? 'UID is valid' : 'Invalid UID format or checksum'
        };
    }
    constructor(uidService){
        this.uidService = uidService;
    }
};
_ts_decorate([
    (0, _common.Get)(':uid'),
    (0, _swagger.ApiOperation)({
        summary: 'Get UID traceability history'
    }),
    _ts_param(0, (0, _common.Param)('uid')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], UidController.prototype, "getUidHistory", null);
_ts_decorate([
    (0, _common.Get)(':uid/validate'),
    (0, _swagger.ApiOperation)({
        summary: 'Validate UID format and checksum'
    }),
    _ts_param(0, (0, _common.Param)('uid')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], UidController.prototype, "validateUid", null);
UidController = _ts_decorate([
    (0, _swagger.ApiTags)('UID Tracking'),
    (0, _common.Controller)('uid'),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _uidservice.UidService === "undefined" ? Object : _uidservice.UidService
    ])
], UidController);

//# sourceMappingURL=uid.controller.js.map