"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "Public", {
    enumerable: true,
    get: function() {
        return Public;
    }
});
const _common = require("@nestjs/common");
const Public = ()=>(0, _common.SetMetadata)('isPublic', true);

//# sourceMappingURL=public.decorator.js.map