"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HrService", {
    enumerable: true,
    get: function() {
        return HrService;
    }
});
const _common = require("@nestjs/common");
const _supabasejs = require("@supabase/supabase-js");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
}
let HrService = class HrService {
    // Employee CRUD
    async createEmployee(tenantId, data) {
        const { data: result, error } = await this.supabase.from('employees').insert([
            {
                ...data,
                tenant_id: tenantId
            }
        ]).select();
        if (error) throw new Error(error.message);
        return result;
    }
    async getEmployees(tenantId) {
        const { data, error } = await this.supabase.from('employees').select('*').eq('tenant_id', tenantId);
        if (error) throw new Error(error.message);
        return data || [];
    }
    async getEmployee(tenantId, id) {
        const { data, error } = await this.supabase.from('employees').select('*').eq('tenant_id', tenantId).eq('id', id).single();
        if (error) throw new Error(error.message);
        return data;
    }
    async updateEmployee(tenantId, id, data) {
        const { data: result, error } = await this.supabase.from('employees').update(data).eq('tenant_id', tenantId).eq('id', id).select();
        if (error) throw new Error(error.message);
        return result;
    }
    async deleteEmployee(tenantId, id) {
        const { error } = await this.supabase.from('employees').delete().eq('tenant_id', tenantId).eq('id', id);
        if (error) throw new Error(error.message);
        return {
            message: 'Employee deleted successfully'
        };
    }
    // Attendance
    async recordAttendance(tenantId, data) {
        const { data: result, error } = await this.supabase.from('attendance_records').insert([
            {
                ...data,
                tenant_id: tenantId
            }
        ]).select();
        if (error) throw new Error(error.message);
        return result;
    }
    async getAttendance(tenantId, employeeId, month) {
        let query = this.supabase.from('attendance_records').select('*');
        if (employeeId) {
            query = query.eq('employee_id', employeeId);
        }
        if (month) {
            query = query.gte('attendance_date', `${month}-01`).lte('attendance_date', `${month}-31`);
        }
        const { data, error } = await query;
        if (error) throw new Error(error.message);
        return data || [];
    }
    // Leave Requests
    async applyLeave(data) {
        return this.supabase.from('leave_requests').insert([
            data
        ]);
    }
    async getLeaves(employeeId) {
        return this.supabase.from('leave_requests').select('*').eq('employee_id', employeeId);
    }
    async approveLeave(id, approverId) {
        return this.supabase.from('leave_requests').update({
            status: 'APPROVED',
            approved_by: approverId,
            approved_at: new Date().toISOString()
        }).eq('id', id);
    }
    async rejectLeave(id, approverId) {
        return this.supabase.from('leave_requests').update({
            status: 'REJECTED',
            approved_by: approverId,
            approved_at: new Date().toISOString()
        }).eq('id', id);
    }
    // Salary Components
    async addSalaryComponent(data) {
        return this.supabase.from('salary_components').insert([
            data
        ]);
    }
    async getSalaryComponents(employeeId) {
        return this.supabase.from('salary_components').select('*').eq('employee_id', employeeId);
    }
    // Payroll Run
    async createPayrollRun(data) {
        return this.supabase.from('payroll_runs').insert([
            data
        ]);
    }
    async getPayrollRuns(tenantId) {
        return this.supabase.from('payroll_runs').select('*').eq('tenant_id', tenantId);
    }
    // Payslip Generation
    async generatePayslip(data) {
        return this.supabase.from('payslips').insert([
            data
        ]);
    }
    async getPayslips(employeeId) {
        return this.supabase.from('payslips').select('*').eq('employee_id', employeeId);
    }
    constructor(){
        this.supabase = (0, _supabasejs.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
    }
};
HrService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [])
], HrService);

//# sourceMappingURL=hr.service.js.map