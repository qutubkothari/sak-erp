"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "BomService", {
    enumerable: true,
    get: function() {
        return BomService;
    }
});
const _common = require("@nestjs/common");
const _supabasejs = require("@supabase/supabase-js");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
}
let BomService = class BomService {
    async create(tenantId, data) {
        console.log('[BomService] create - Input data:', JSON.stringify(data, null, 2));
        const { data: bom, error } = await this.supabase.from('bom_headers').insert({
            tenant_id: tenantId,
            item_id: data.itemId,
            version: data.version || 1,
            is_active: true,
            effective_from: data.effectiveFrom || new Date().toISOString(),
            effective_to: data.effectiveTo,
            notes: data.notes
        }).select().single();
        if (error) throw new _common.BadRequestException(error.message);
        console.log('[BomService] create - BOM header created:', bom.id);
        // Insert BOM items
        if (data.items && data.items.length > 0) {
            console.log('[BomService] create - Component item IDs:', data.items.map((i)=>i.itemId));
            const items = data.items.map((item, index)=>({
                    bom_id: bom.id,
                    item_id: item.itemId,
                    quantity: item.quantity,
                    scrap_percentage: item.scrapPercentage || 0,
                    sequence: item.sequence || index + 1,
                    notes: item.notes,
                    drawing_url: item.drawingUrl
                }));
            const { error: itemsError } = await this.supabase.from('bom_items').insert(items);
            if (itemsError) throw new _common.BadRequestException(itemsError.message);
        }
        return this.findOne(tenantId, bom.id);
    }
    async findAll(tenantId, filters) {
        // Fetch BOM headers
        let query = this.supabase.from('bom_headers').select('*').eq('tenant_id', tenantId).order('created_at', {
            ascending: false
        });
        if (filters?.itemId || filters?.productId) {
            query = query.eq('item_id', filters.itemId || filters.productId);
        }
        if (filters?.isActive !== undefined) {
            query = query.eq('is_active', filters.isActive);
        }
        const { data: headers, error } = await query;
        if (error) throw new _common.BadRequestException(error.message);
        if (!headers || headers.length === 0) return [];
        // Fetch all related items and bom_items in parallel
        const itemIds = headers.map((h)=>h.item_id);
        const bomIds = headers.map((h)=>h.id);
        console.log('[BomService] findAll - fetching items for IDs:', itemIds);
        console.log('[BomService] findAll - fetching bom_items for BOM IDs:', bomIds);
        const [itemsRes, bomItemsRes] = await Promise.all([
            this.supabase.from('items').select('*').in('id', itemIds),
            this.supabase.from('bom_items').select('*').in('bom_id', bomIds)
        ]);
        if (itemsRes.error) {
            console.error('[BomService] Items query error:', itemsRes.error);
            throw new _common.BadRequestException(itemsRes.error.message);
        }
        if (bomItemsRes.error) {
            console.error('[BomService] BOM items query error:', bomItemsRes.error);
            throw new _common.BadRequestException(bomItemsRes.error.message);
        }
        console.log('[BomService] Items found:', itemsRes.data?.length);
        console.log('[BomService] BOM items found:', bomItemsRes.data?.length);
        const itemsMap = new Map(itemsRes.data?.map((i)=>[
                i.id,
                i
            ]));
        const bomItemsMap = new Map();
        // Group bom_items by bom_id
        bomItemsRes.data?.forEach((bi)=>{
            if (!bomItemsMap.has(bi.bom_id)) {
                bomItemsMap.set(bi.bom_id, []);
            }
            bomItemsMap.get(bi.bom_id).push({
                ...bi,
                item: itemsMap.get(bi.item_id)
            });
        });
        // Combine everything
        return headers.map((h)=>({
                ...h,
                item: itemsMap.get(h.item_id),
                bom_items: bomItemsMap.get(h.id) || []
            }));
    }
    async findOne(tenantId, id) {
        // Fetch BOM header
        const { data: header, error } = await this.supabase.from('bom_headers').select('*').eq('tenant_id', tenantId).eq('id', id).single();
        if (error) throw new _common.NotFoundException('BOM not found');
        // Fetch item and bom_items
        const [itemRes, bomItemsRes] = await Promise.all([
            this.supabase.from('items').select('*').eq('id', header.item_id).single(),
            this.supabase.from('bom_items').select('*').eq('bom_id', id)
        ]);
        if (itemRes.error) throw new _common.BadRequestException(itemRes.error.message);
        if (bomItemsRes.error) throw new _common.BadRequestException(bomItemsRes.error.message);
        // Fetch items for bom_items
        const bomItemIds = bomItemsRes.data?.map((bi)=>bi.item_id) || [];
        const { data: bomItems, error: bomItemsItemsError } = await this.supabase.from('items').select('*').in('id', bomItemIds);
        if (bomItemsItemsError) throw new _common.BadRequestException(bomItemsItemsError.message);
        const itemsMap = new Map(bomItems?.map((i)=>[
                i.id,
                i
            ]));
        return {
            ...header,
            item: itemRes.data,
            bom_items: bomItemsRes.data?.map((bi)=>({
                    ...bi,
                    item: itemsMap.get(bi.item_id)
                })) || []
        };
    }
    async update(tenantId, id, data) {
        const { error } = await this.supabase.from('bom_headers').update({
            effective_from: data.effectiveFrom,
            effective_to: data.effectiveTo,
            notes: data.notes,
            updated_at: new Date().toISOString()
        }).eq('tenant_id', tenantId).eq('id', id);
        if (error) throw new _common.BadRequestException(error.message);
        // Update items if provided
        if (data.items) {
            await this.supabase.from('bom_items').delete().eq('bom_id', id);
            if (data.items.length > 0) {
                const items = data.items.map((item, index)=>({
                        bom_id: id,
                        item_id: item.itemId,
                        quantity: item.quantity,
                        scrap_percentage: item.scrapPercentage || 0,
                        sequence: item.sequence || index + 1,
                        notes: item.notes,
                        drawing_url: item.drawingUrl
                    }));
                await this.supabase.from('bom_items').insert(items);
            }
        }
        return this.findOne(tenantId, id);
    }
    async generatePurchaseRequisition(tenantId, userId, bomId, quantity) {
        // Get BOM with all items
        const bom = await this.findOne(tenantId, bomId);
        if (!bom.bom_items || bom.bom_items.length === 0) {
            throw new _common.BadRequestException('BOM has no items');
        }
        // Check stock availability for each item
        const itemsToOrder = [];
        for (const bomItem of bom.bom_items){
            const requiredQty = bomItem.quantity * quantity * (1 + (bomItem.scrap_percentage || 0) / 100);
            // Check current stock
            const { data: stock } = await this.supabase.from('stock_entries').select('available_quantity').eq('tenant_id', tenantId).eq('item_id', bomItem.item_id);
            const availableQty = stock?.reduce((sum, s)=>sum + s.available_quantity, 0) || 0;
            const shortfall = requiredQty - availableQty;
            if (shortfall > 0) {
                itemsToOrder.push({
                    itemId: bomItem.item_id,
                    itemCode: bomItem.item.code,
                    itemName: bomItem.item.name,
                    quantity: Math.ceil(shortfall),
                    specifications: bomItem.notes,
                    drawingUrl: bomItem.drawing_url
                });
            }
        }
        if (itemsToOrder.length === 0) {
            return {
                message: 'All items are in stock',
                itemsToOrder: []
            };
        }
        // Create Purchase Requisition
        const prData = {
            department: 'PRODUCTION',
            requiredDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            priority: 'MEDIUM',
            notes: `Auto-generated from BOM ${bom.item.code} - ${bom.item.name} (Qty: ${quantity})`,
            items: itemsToOrder.map((item)=>({
                    itemId: item.itemId,
                    quantity: item.quantity,
                    specifications: item.specifications,
                    drawingUrl: item.drawingUrl
                }))
        };
        // Call PR service to create
        const { data: pr, error } = await this.supabase.from('purchase_requisitions').insert({
            tenant_id: tenantId,
            pr_number: await this.generatePRNumber(tenantId),
            department: prData.department,
            requested_by: userId,
            required_date: prData.requiredDate,
            status: 'DRAFT',
            priority: prData.priority,
            notes: prData.notes
        }).select().single();
        if (error) throw new _common.BadRequestException(error.message);
        // Insert PR items
        const prItems = prData.items.map((item)=>({
                pr_id: pr.id,
                item_id: item.itemId,
                quantity: item.quantity,
                specifications: item.specifications,
                notes: `Drawing: ${item.drawingUrl || 'Not attached'}`
            }));
        await this.supabase.from('purchase_requisition_items').insert(prItems);
        return {
            message: 'Purchase Requisition generated from BOM',
            prNumber: pr.pr_number,
            prId: pr.id,
            itemsToOrder
        };
    }
    async delete(tenantId, id) {
        const { error } = await this.supabase.from('bom_headers').delete().eq('tenant_id', tenantId).eq('id', id);
        if (error) throw new _common.BadRequestException(error.message);
        return {
            message: 'BOM deleted successfully'
        };
    }
    async generatePRNumber(tenantId) {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const prefix = `PR-${year}-${month}`;
        const { data } = await this.supabase.from('purchase_requisitions').select('pr_number').eq('tenant_id', tenantId).like('pr_number', `${prefix}%`).order('pr_number', {
            ascending: false
        }).limit(1).single();
        if (!data) {
            return `${prefix}-001`;
        }
        const lastNumber = parseInt(data.pr_number.split('-').pop() || '0');
        return `${prefix}-${String(lastNumber + 1).padStart(3, '0')}`;
    }
    constructor(){
        this.supabase = (0, _supabasejs.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
    }
};
BomService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [])
], BomService);

//# sourceMappingURL=bom.service.js.map