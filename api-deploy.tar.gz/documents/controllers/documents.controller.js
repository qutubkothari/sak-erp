"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DocumentsController", {
    enumerable: true,
    get: function() {
        return DocumentsController;
    }
});
const _common = require("@nestjs/common");
const _documentsservice = require("../services/documents.service");
const _documentrevisionsservice = require("../services/document-revisions.service");
const _jwtauthguard = require("../../auth/guards/jwt-auth.guard");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let DocumentsController = class DocumentsController {
    create(req, createDto) {
        return this.documentsService.create(req, createDto);
    }
    findAll(req, filters) {
        return this.documentsService.findAll(req, filters);
    }
    getPendingApprovals(req) {
        return this.documentsService.getPendingApprovals(req);
    }
    findOne(req, id) {
        return this.documentsService.findOne(req, id);
    }
    update(req, id, updateDto) {
        return this.documentsService.update(req, id, updateDto);
    }
    delete(req, id) {
        return this.documentsService.delete(req, id);
    }
    addRevision(req, id, revisionDto) {
        return this.documentsService.addRevision(req, id, revisionDto);
    }
    getRevisions(req, id) {
        return this.revisionsService.findAllByDocument(req, id);
    }
    submitForApproval(req, id, approvalWorkflow) {
        return this.documentsService.submitForApproval(req, id, approvalWorkflow);
    }
    approveDocument(req, id, approvalId, body) {
        return this.documentsService.approveDocument(req, id, approvalId, body.comments);
    }
    rejectDocument(req, id, approvalId, body) {
        return this.documentsService.rejectDocument(req, id, approvalId, body.reason);
    }
    archiveDocument(req, id) {
        return this.documentsService.archiveDocument(req, id);
    }
    getAccessLogs(req, id) {
        return this.documentsService.getAccessLogs(req, id);
    }
    constructor(documentsService, revisionsService){
        this.documentsService = documentsService;
        this.revisionsService = revisionsService;
    }
};
_ts_decorate([
    (0, _common.Post)(),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "create", null);
_ts_decorate([
    (0, _common.Get)(),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Query)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "findAll", null);
_ts_decorate([
    (0, _common.Get)('pending-approvals'),
    _ts_param(0, (0, _common.Request)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "getPendingApprovals", null);
_ts_decorate([
    (0, _common.Get)(':id'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "findOne", null);
_ts_decorate([
    (0, _common.Put)(':id'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_param(2, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "update", null);
_ts_decorate([
    (0, _common.Delete)(':id'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "delete", null);
_ts_decorate([
    (0, _common.Post)(':id/revisions'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_param(2, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "addRevision", null);
_ts_decorate([
    (0, _common.Get)(':id/revisions'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "getRevisions", null);
_ts_decorate([
    (0, _common.Post)(':id/submit-approval'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_param(2, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "submitForApproval", null);
_ts_decorate([
    (0, _common.Post)(':id/approve/:approvalId'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_param(2, (0, _common.Param)('approvalId')),
    _ts_param(3, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        String,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "approveDocument", null);
_ts_decorate([
    (0, _common.Post)(':id/reject/:approvalId'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_param(2, (0, _common.Param)('approvalId')),
    _ts_param(3, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        String,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "rejectDocument", null);
_ts_decorate([
    (0, _common.Post)(':id/archive'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "archiveDocument", null);
_ts_decorate([
    (0, _common.Get)(':id/access-logs'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], DocumentsController.prototype, "getAccessLogs", null);
DocumentsController = _ts_decorate([
    (0, _common.Controller)('documents'),
    (0, _common.UseGuards)(_jwtauthguard.JwtAuthGuard),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _documentsservice.DocumentsService === "undefined" ? Object : _documentsservice.DocumentsService,
        typeof _documentrevisionsservice.DocumentRevisionsService === "undefined" ? Object : _documentrevisionsservice.DocumentRevisionsService
    ])
], DocumentsController);

//# sourceMappingURL=documents.controller.js.map