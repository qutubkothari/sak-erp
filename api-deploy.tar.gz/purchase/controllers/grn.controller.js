"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "GrnController", {
    enumerable: true,
    get: function() {
        return GrnController;
    }
});
const _common = require("@nestjs/common");
const _grnservice = require("../services/grn.service");
const _jwtauthguard = require("../../auth/guards/jwt-auth.guard");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let GrnController = class GrnController {
    async create(req, body) {
        return this.grnService.create(req.user.tenantId, req.user.userId, body);
    }
    async findAll(req, query) {
        return this.grnService.findAll(req.user.tenantId, query);
    }
    async findOne(req, id) {
        return this.grnService.findOne(req.user.tenantId, id);
    }
    async update(req, id, body) {
        return this.grnService.update(req.user.tenantId, id, body);
    }
    async submit(req, id) {
        return this.grnService.submit(req.user.tenantId, id, req.user.userId);
    }
    async delete(req, id) {
        return this.grnService.delete(req.user.tenantId, id);
    }
    async generateUIDs(req, itemId, body) {
        return this.grnService.generateUIDs(req.user.tenantId, itemId, body);
    }
    async getUIDsByGRN(req, id) {
        return this.grnService.getUIDsByGRN(req.user.tenantId, id);
    }
    constructor(grnService){
        this.grnService = grnService;
    }
};
_ts_decorate([
    (0, _common.Post)(),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], GrnController.prototype, "create", null);
_ts_decorate([
    (0, _common.Get)(),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Query)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], GrnController.prototype, "findAll", null);
_ts_decorate([
    (0, _common.Get)(':id'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], GrnController.prototype, "findOne", null);
_ts_decorate([
    (0, _common.Put)(':id'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_param(2, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], GrnController.prototype, "update", null);
_ts_decorate([
    (0, _common.Post)(':id/submit'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], GrnController.prototype, "submit", null);
_ts_decorate([
    (0, _common.Delete)(':id'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], GrnController.prototype, "delete", null);
_ts_decorate([
    (0, _common.Post)('items/:itemId/generate-uids'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('itemId')),
    _ts_param(2, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], GrnController.prototype, "generateUIDs", null);
_ts_decorate([
    (0, _common.Get)(':id/uids'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], GrnController.prototype, "getUIDsByGRN", null);
GrnController = _ts_decorate([
    (0, _common.Controller)('purchase/grn'),
    (0, _common.UseGuards)(_jwtauthguard.JwtAuthGuard),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _grnservice.GrnService === "undefined" ? Object : _grnservice.GrnService
    ])
], GrnController);

//# sourceMappingURL=grn.controller.js.map