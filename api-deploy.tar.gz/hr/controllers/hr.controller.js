"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HrController", {
    enumerable: true,
    get: function() {
        return HrController;
    }
});
const _common = require("@nestjs/common");
const _hrservice = require("../services/hr.service");
const _jwtauthguard = require("../../auth/guards/jwt-auth.guard");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let HrController = class HrController {
    // Employee CRUD
    createEmployee(req, body) {
        return this.hrService.createEmployee(req.user.tenantId, body);
    }
    getEmployees(req) {
        return this.hrService.getEmployees(req.user.tenantId);
    }
    getEmployee(req, id) {
        return this.hrService.getEmployee(req.user.tenantId, id);
    }
    updateEmployee(req, id, body) {
        return this.hrService.updateEmployee(req.user.tenantId, id, body);
    }
    deleteEmployee(req, id) {
        return this.hrService.deleteEmployee(req.user.tenantId, id);
    }
    // Attendance
    recordAttendance(req, body) {
        return this.hrService.recordAttendance(req.user.tenantId, body);
    }
    getAttendance(req, employeeId, month) {
        return this.hrService.getAttendance(req.user.tenantId, employeeId, month);
    }
    // Leave Requests
    applyLeave(body) {
        return this.hrService.applyLeave(body);
    }
    getLeaves(employeeId) {
        return this.hrService.getLeaves(employeeId);
    }
    approveLeave(id, approverId) {
        return this.hrService.approveLeave(id, approverId);
    }
    rejectLeave(id, approverId) {
        return this.hrService.rejectLeave(id, approverId);
    }
    // Salary Components
    addSalaryComponent(body) {
        return this.hrService.addSalaryComponent(body);
    }
    getSalaryComponents(employeeId) {
        return this.hrService.getSalaryComponents(employeeId);
    }
    // Payroll Run
    createPayrollRun(body) {
        return this.hrService.createPayrollRun(body);
    }
    getPayrollRuns(tenantId) {
        return this.hrService.getPayrollRuns(tenantId);
    }
    // Payslip Generation
    generatePayslip(body) {
        return this.hrService.generatePayslip(body);
    }
    getPayslips(employeeId) {
        return this.hrService.getPayslips(employeeId);
    }
    constructor(hrService){
        this.hrService = hrService;
    }
};
_ts_decorate([
    (0, _common.Post)('employees'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "createEmployee", null);
_ts_decorate([
    (0, _common.Get)('employees'),
    _ts_param(0, (0, _common.Request)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "getEmployees", null);
_ts_decorate([
    (0, _common.Get)('employees/:id'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "getEmployee", null);
_ts_decorate([
    (0, _common.Put)('employees/:id'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_param(2, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "updateEmployee", null);
_ts_decorate([
    (0, _common.Delete)('employees/:id'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "deleteEmployee", null);
_ts_decorate([
    (0, _common.Post)('attendance'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "recordAttendance", null);
_ts_decorate([
    (0, _common.Get)('attendance'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Query)('employeeId')),
    _ts_param(2, (0, _common.Query)('month')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "getAttendance", null);
_ts_decorate([
    (0, _common.Post)('leaves'),
    _ts_param(0, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "applyLeave", null);
_ts_decorate([
    (0, _common.Get)('leaves'),
    _ts_param(0, (0, _common.Query)('employeeId')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "getLeaves", null);
_ts_decorate([
    (0, _common.Put)('leaves/:id/approve'),
    _ts_param(0, (0, _common.Param)('id')),
    _ts_param(1, (0, _common.Body)('approverId')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "approveLeave", null);
_ts_decorate([
    (0, _common.Put)('leaves/:id/reject'),
    _ts_param(0, (0, _common.Param)('id')),
    _ts_param(1, (0, _common.Body)('approverId')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "rejectLeave", null);
_ts_decorate([
    (0, _common.Post)('salary-components'),
    _ts_param(0, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "addSalaryComponent", null);
_ts_decorate([
    (0, _common.Get)('salary-components'),
    _ts_param(0, (0, _common.Query)('employeeId')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "getSalaryComponents", null);
_ts_decorate([
    (0, _common.Post)('payroll-runs'),
    _ts_param(0, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "createPayrollRun", null);
_ts_decorate([
    (0, _common.Get)('payroll-runs'),
    _ts_param(0, (0, _common.Query)('tenantId')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "getPayrollRuns", null);
_ts_decorate([
    (0, _common.Post)('payslips'),
    _ts_param(0, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "generatePayslip", null);
_ts_decorate([
    (0, _common.Get)('payslips'),
    _ts_param(0, (0, _common.Query)('employeeId')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], HrController.prototype, "getPayslips", null);
HrController = _ts_decorate([
    (0, _common.Controller)('hr'),
    (0, _common.UseGuards)(_jwtauthguard.JwtAuthGuard),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _hrservice.HrService === "undefined" ? Object : _hrservice.HrService
    ])
], HrController);

//# sourceMappingURL=hr.controller.js.map