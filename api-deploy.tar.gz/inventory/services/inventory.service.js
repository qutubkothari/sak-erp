"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "InventoryService", {
    enumerable: true,
    get: function() {
        return InventoryService;
    }
});
const _common = require("@nestjs/common");
const _supabasejs = require("@supabase/supabase-js");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
}
let InventoryService = class InventoryService {
    // Get current stock levels with filters
    async getStockLevels(req, filters) {
        const { tenantId } = req.user;
        let query = this.supabase.from('inventory_stock').select('*').eq('tenant_id', tenantId);
        if (filters?.warehouse_id) {
            query = query.eq('warehouse_id', filters.warehouse_id);
        }
        if (filters?.category) {
            query = query.eq('category', filters.category);
        }
        if (filters?.item_id) {
            query = query.eq('item_id', filters.item_id);
        }
        if (filters?.low_stock) {
            // Compare available_quantity with reorder_point column
            query = query.lte('available_quantity', 'reorder_point');
        }
        const { data, error } = await query.order('updated_at', {
            ascending: false
        });
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    // Get stock movements history
    async getStockMovements(req, filters) {
        const { tenantId } = req.user;
        let query = this.supabase.from('stock_movements').select('*').eq('tenant_id', tenantId);
        if (filters?.movement_type) {
            query = query.eq('movement_type', filters.movement_type);
        }
        if (filters?.item_id) {
            query = query.eq('item_id', filters.item_id);
        }
        if (filters?.uid) {
            query = query.eq('uid', filters.uid);
        }
        if (filters?.from_date) {
            query = query.gte('movement_date', filters.from_date);
        }
        if (filters?.to_date) {
            query = query.lte('movement_date', filters.to_date);
        }
        const { data, error } = await query.order('movement_date', {
            ascending: false
        }).limit(filters?.limit || 100);
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    // Create stock movement (generic)
    async createStockMovement(req, movementData) {
        const { tenantId, userId } = req.user;
        // Generate movement number
        const movementNumber = await this.generateMovementNumber(req, movementData.movement_type);
        const movement = {
            tenant_id: tenantId,
            movement_number: movementNumber,
            movement_type: movementData.movement_type,
            item_id: movementData.item_id,
            uid: movementData.uid,
            from_warehouse_id: movementData.from_warehouse_id,
            from_location_id: movementData.from_location_id,
            to_warehouse_id: movementData.to_warehouse_id,
            to_location_id: movementData.to_location_id,
            quantity: movementData.quantity,
            reference_type: movementData.reference_type,
            reference_id: movementData.reference_id,
            reference_number: movementData.reference_number,
            batch_number: movementData.batch_number,
            notes: movementData.notes,
            moved_by: userId,
            movement_date: movementData.movement_date || new Date().toISOString()
        };
        // Insert movement
        const { data: movementRecord, error: movementError } = await this.supabase.from('stock_movements').insert(movement).select().single();
        if (movementError) throw new _common.BadRequestException(movementError.message);
        // Update stock levels
        await this.updateStockLevels(req, movementData);
        // Check for low stock alerts
        await this.checkLowStockAlerts(req, movementData.item_id, movementData.to_warehouse_id || movementData.from_warehouse_id);
        return movementRecord;
    }
    // Update stock levels after movement
    async updateStockLevels(req, movementData) {
        const { tenantId } = req.user;
        // Decrease from source warehouse
        if (movementData.from_warehouse_id) {
            await this.adjustStock(req, movementData.item_id, movementData.from_warehouse_id, movementData.from_location_id, -movementData.quantity);
        }
        // Increase at destination warehouse
        if (movementData.to_warehouse_id) {
            await this.adjustStock(req, movementData.item_id, movementData.to_warehouse_id, movementData.to_location_id, movementData.quantity, movementData.category);
        }
    }
    // Adjust stock quantity (upsert)
    async adjustStock(req, itemId, warehouseId, locationId, quantityChange, category) {
        const { tenantId } = req.user;
        // Get current stock
        const { data: currentStock } = await this.supabase.from('inventory_stock').select('*').eq('tenant_id', tenantId).eq('item_id', itemId).eq('warehouse_id', warehouseId).eq('location_id', locationId || 'null').maybeSingle();
        if (currentStock) {
            // Update existing stock
            const newQuantity = parseFloat(currentStock.quantity) + quantityChange;
            await this.supabase.from('inventory_stock').update({
                quantity: newQuantity,
                last_movement_date: new Date().toISOString(),
                updated_at: new Date().toISOString()
            }).eq('id', currentStock.id);
        } else {
            // Create new stock record (for receipts)
            if (quantityChange > 0) {
                await this.supabase.from('inventory_stock').insert({
                    tenant_id: tenantId,
                    item_id: itemId,
                    warehouse_id: warehouseId,
                    location_id: locationId,
                    category: category || 'RAW_MATERIAL',
                    quantity: quantityChange,
                    last_movement_date: new Date().toISOString()
                });
            }
        }
    }
    // Generate movement number
    async generateMovementNumber(req, movementType) {
        const { tenantId } = req.user;
        const prefix = this.getMovementPrefix(movementType);
        const { count } = await this.supabase.from('stock_movements').select('*', {
            count: 'exact',
            head: true
        }).eq('tenant_id', tenantId).like('movement_number', `${prefix}%`);
        return `${prefix}${String((count || 0) + 1).padStart(6, '0')}`;
    }
    getMovementPrefix(movementType) {
        const prefixes = {
            GRN_RECEIPT: 'RCP-',
            PRODUCTION_ISSUE: 'ISS-',
            PRODUCTION_RETURN: 'RET-',
            PRODUCTION_RECEIPT: 'PRD-',
            SALES_ISSUE: 'SAL-',
            DEMO_ISSUE: 'DMO-',
            DEMO_RETURN: 'DMR-',
            DEMO_SOLD: 'DMS-',
            SERVICE_ISSUE: 'SRV-',
            TRANSFER: 'TRN-',
            ADJUSTMENT: 'ADJ-',
            SCRAP: 'SCR-'
        };
        return prefixes[movementType] || 'MOV-';
    }
    // Reserve stock for production/sales
    async reserveStock(req, reservationData) {
        const { tenantId, userId } = req.user;
        // Check available quantity
        const { data: stock } = await this.supabase.from('inventory_stock').select('available_quantity').eq('tenant_id', tenantId).eq('item_id', reservationData.item_id).eq('warehouse_id', reservationData.warehouse_id).single();
        if (!stock || parseFloat(stock.available_quantity) < reservationData.reserved_quantity) {
            throw new _common.BadRequestException('Insufficient stock available for reservation');
        }
        // Create reservation
        const reservation = {
            tenant_id: tenantId,
            item_id: reservationData.item_id,
            warehouse_id: reservationData.warehouse_id,
            reserved_quantity: reservationData.reserved_quantity,
            reference_type: reservationData.reference_type,
            reference_id: reservationData.reference_id,
            reference_number: reservationData.reference_number,
            reserved_by: userId,
            expires_at: reservationData.expires_at
        };
        const { data, error } = await this.supabase.from('stock_reservations').insert(reservation).select().single();
        if (error) throw new _common.BadRequestException(error.message);
        // Update stock reserved_quantity
        await this.supabase.rpc('increment_reserved_quantity', {
            p_tenant_id: tenantId,
            p_item_id: reservationData.item_id,
            p_warehouse_id: reservationData.warehouse_id,
            p_quantity: reservationData.reserved_quantity
        });
        return data;
    }
    // Release stock reservation
    async releaseReservation(req, reservationId) {
        const { tenantId } = req.user;
        const { data: reservation } = await this.supabase.from('stock_reservations').select('*').eq('id', reservationId).eq('tenant_id', tenantId).single();
        if (!reservation) throw new _common.NotFoundException('Reservation not found');
        // Update reservation
        await this.supabase.from('stock_reservations').update({
            released: true,
            released_at: new Date().toISOString()
        }).eq('id', reservationId);
        // Decrease stock reserved_quantity
        await this.supabase.rpc('decrement_reserved_quantity', {
            p_tenant_id: tenantId,
            p_item_id: reservation.item_id,
            p_warehouse_id: reservation.warehouse_id,
            p_quantity: reservation.reserved_quantity
        });
        return {
            message: 'Reservation released successfully'
        };
    }
    // Check and create low stock alerts
    async checkLowStockAlerts(req, itemId, warehouseId) {
        const { tenantId } = req.user;
        const { data: stock } = await this.supabase.from('inventory_stock').select('*').eq('tenant_id', tenantId).eq('item_id', itemId).eq('warehouse_id', warehouseId).single();
        if (stock && parseFloat(stock.available_quantity) <= parseFloat(stock.reorder_point)) {
            // Check if alert already exists
            const { data: existingAlert } = await this.supabase.from('inventory_alerts').select('id').eq('tenant_id', tenantId).eq('item_id', itemId).eq('warehouse_id', warehouseId).eq('alert_type', 'LOW_STOCK').eq('acknowledged', false).maybeSingle();
            if (!existingAlert) {
                await this.supabase.from('inventory_alerts').insert({
                    tenant_id: tenantId,
                    alert_type: 'LOW_STOCK',
                    item_id: itemId,
                    warehouse_id: warehouseId,
                    current_quantity: stock.available_quantity,
                    threshold_quantity: stock.reorder_point,
                    message: `Low stock alert: Item ${itemId} - Available: ${stock.available_quantity}, Reorder Point: ${stock.reorder_point}`,
                    severity: parseFloat(stock.available_quantity) <= 0 ? 'CRITICAL' : 'HIGH'
                });
            }
        }
    }
    // Get inventory alerts
    async getAlerts(req, acknowledged) {
        const { tenantId } = req.user;
        let query = this.supabase.from('inventory_alerts').select('*').eq('tenant_id', tenantId);
        if (acknowledged !== undefined) {
            query = query.eq('acknowledged', acknowledged);
        }
        const { data, error } = await query.order('created_at', {
            ascending: false
        });
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    // Acknowledge alert
    async acknowledgeAlert(req, alertId) {
        const { tenantId, userId } = req.user;
        const { error } = await this.supabase.from('inventory_alerts').update({
            acknowledged: true,
            acknowledged_by: userId,
            acknowledged_at: new Date().toISOString()
        }).eq('id', alertId).eq('tenant_id', tenantId);
        if (error) throw new _common.BadRequestException(error.message);
        return {
            message: 'Alert acknowledged successfully'
        };
    }
    // Demo inventory management
    async issueDemoStock(req, demoData) {
        const { tenantId, userId } = req.user;
        // Generate demo ID
        const demoId = await this.generateDemoId(req);
        const demo = {
            tenant_id: tenantId,
            demo_id: demoId,
            uid: demoData.uid,
            item_id: demoData.item_id,
            issued_to_staff_id: demoData.issued_to_staff_id,
            customer_name: demoData.customer_name,
            customer_contact: demoData.customer_contact,
            issue_date: demoData.issue_date || new Date().toISOString().split('T')[0],
            expected_return_date: demoData.expected_return_date,
            warehouse_id: demoData.warehouse_id,
            status: 'ISSUED'
        };
        const { data, error } = await this.supabase.from('demo_inventory').insert(demo).select().single();
        if (error) throw new _common.BadRequestException(error.message);
        // Create stock movement for demo issue
        await this.createStockMovement(req, {
            movement_type: 'DEMO_ISSUE',
            item_id: demoData.item_id,
            uid: demoData.uid,
            from_warehouse_id: demoData.warehouse_id,
            quantity: 1,
            reference_type: 'DEMO',
            reference_id: data.id,
            reference_number: demoId,
            notes: `Demo issued to ${demoData.issued_to_staff_id} for ${demoData.customer_name}`
        });
        return data;
    }
    // Return demo stock
    async returnDemoStock(req, demoId, returnData) {
        const { tenantId } = req.user;
        const { data: demo } = await this.supabase.from('demo_inventory').select('*').eq('demo_id', demoId).eq('tenant_id', tenantId).single();
        if (!demo) throw new _common.NotFoundException('Demo record not found');
        // Update demo record
        const { data: updatedDemo, error } = await this.supabase.from('demo_inventory').update({
            status: 'RETURNED',
            actual_return_date: returnData.return_date || new Date().toISOString().split('T')[0],
            inspection_notes: returnData.inspection_notes,
            updated_at: new Date().toISOString()
        }).eq('id', demo.id).select().single();
        if (error) throw new _common.BadRequestException(error.message);
        // Create stock movement for demo return
        await this.createStockMovement(req, {
            movement_type: 'DEMO_RETURN',
            item_id: demo.item_id,
            uid: demo.uid,
            to_warehouse_id: demo.warehouse_id,
            quantity: 1,
            reference_type: 'DEMO',
            reference_id: demo.id,
            reference_number: demoId,
            notes: returnData.inspection_notes
        });
        return updatedDemo;
    }
    // Convert demo to sale
    async convertDemoToSale(req, demoId, salesOrderId) {
        const { tenantId } = req.user;
        const { data: demo } = await this.supabase.from('demo_inventory').select('*').eq('demo_id', demoId).eq('tenant_id', tenantId).single();
        if (!demo) throw new _common.NotFoundException('Demo record not found');
        // Update demo record
        const { error } = await this.supabase.from('demo_inventory').update({
            status: 'SOLD',
            converted_to_sale: true,
            sales_order_id: salesOrderId,
            updated_at: new Date().toISOString()
        }).eq('id', demo.id);
        if (error) throw new _common.BadRequestException(error.message);
        // Create stock movement for demo sold
        await this.createStockMovement(req, {
            movement_type: 'DEMO_SOLD',
            item_id: demo.item_id,
            uid: demo.uid,
            from_warehouse_id: demo.warehouse_id,
            quantity: 1,
            reference_type: 'SALES_ORDER',
            reference_id: salesOrderId,
            reference_number: demoId,
            notes: `Demo converted to sale for ${demo.customer_name}`
        });
        return {
            message: 'Demo converted to sale successfully',
            demo_expenses: demo.demo_expenses
        };
    }
    // Get demo inventory
    async getDemoInventory(req, filters) {
        const { tenantId } = req.user;
        let query = this.supabase.from('demo_inventory').select('*').eq('tenant_id', tenantId);
        if (filters?.status) {
            query = query.eq('status', filters.status);
        }
        if (filters?.staff_id) {
            query = query.eq('issued_to_staff_id', filters.staff_id);
        }
        const { data, error } = await query.order('issue_date', {
            ascending: false
        });
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    async generateDemoId(req) {
        const { tenantId } = req.user;
        const { count } = await this.supabase.from('demo_inventory').select('*', {
            count: 'exact',
            head: true
        }).eq('tenant_id', tenantId);
        return `DEMO-${String((count || 0) + 1).padStart(6, '0')}`;
    }
    // Get warehouses
    async getWarehouses(req) {
        const { tenantId } = req.user;
        const { data, error } = await this.supabase.from('warehouses').select('*').eq('tenant_id', tenantId).eq('is_active', true).order('name');
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    // Create warehouse
    async createWarehouse(req, warehouseData) {
        const { tenantId } = req.user;
        const warehouse = {
            tenant_id: tenantId,
            code: warehouseData.code || warehouseData.warehouse_code,
            name: warehouseData.name || warehouseData.warehouse_name,
            type: warehouseData.type,
            plant_id: warehouseData.plant_id,
            is_active: true,
            metadata: warehouseData.metadata || {}
        };
        const { data, error } = await this.supabase.from('warehouses').insert(warehouse).select().single();
        if (error) throw new _common.BadRequestException(error.message);
        return data;
    }
    constructor(){
        this.supabase = (0, _supabasejs.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
    }
};
InventoryService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [])
], InventoryService);

//# sourceMappingURL=inventory.service.js.map