"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ItemsService", {
    enumerable: true,
    get: function() {
        return ItemsService;
    }
});
const _common = require("@nestjs/common");
const _supabasejs = require("@supabase/supabase-js");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
let ItemsService = class ItemsService {
    async findAll(tenantId, search, includeInactive) {
        console.log('[ItemsService] findAll called:', {
            tenantId,
            search,
            includeInactive
        });
        let query = this.supabase.from('items').select('*').eq('tenant_id', tenantId).order('name', {
            ascending: true
        });
        // Only filter by is_active if we're not including inactive items
        if (!includeInactive) {
            console.log('[ItemsService] Filtering for active items only');
            query = query.eq('is_active', true);
        } else {
            console.log('[ItemsService] Including inactive items');
        }
        if (search) {
            query = query.or(`code.ilike.%${search}%,name.ilike.%${search}%,description.ilike.%${search}%`);
        }
        const { data, error } = await query;
        if (error) {
            console.error('[ItemsService] Query error:', error);
            throw new Error(`Failed to fetch items: ${error.message}`);
        }
        console.log('[ItemsService] Query successful:', {
            count: data?.length || 0
        });
        return data || [];
    }
    async search(tenantId, query) {
        if (!query || query.trim().length === 0) {
            return [];
        }
        const searchTerm = query.trim();
        const { data, error } = await this.supabase.from('items').select('id, code, name, description, uom, category').eq('tenant_id', tenantId).eq('is_active', true).or(`code.ilike.%${searchTerm}%,name.ilike.%${searchTerm}%,description.ilike.%${searchTerm}%`).limit(20).order('name', {
            ascending: true
        });
        if (error) {
            throw new Error(`Search failed: ${error.message}`);
        }
        return data || [];
    }
    async findOne(tenantId, id) {
        const { data, error } = await this.supabase.from('items').select('*').eq('tenant_id', tenantId).eq('id', id).single();
        if (error) {
            throw new Error(`Failed to fetch item: ${error.message}`);
        }
        return data;
    }
    async create(tenantId, itemData) {
        // Validate HSN code if provided
        let validatedHsn = null;
        if (itemData.hsnCode || itemData.hsn_code) {
            const hsnStr = String(itemData.hsnCode || itemData.hsn_code).trim();
            if (/^\d{4}$|^\d{6}$|^\d{8}$/.test(hsnStr)) {
                validatedHsn = hsnStr;
            }
        }
        const { data, error } = await this.supabase.from('items').insert({
            tenant_id: tenantId,
            code: itemData.code,
            name: itemData.name,
            description: itemData.description,
            category: itemData.category,
            uom: itemData.uom,
            reorder_level: itemData.reorderLevel,
            min_stock: itemData.minStock,
            max_stock: itemData.maxStock,
            standard_cost: itemData.standardCost,
            hsn_code: validatedHsn,
            is_active: true,
            metadata: itemData.metadata || {}
        }).select().single();
        if (error) {
            throw new Error(`Failed to create item: ${error.message}`);
        }
        return data;
    }
    async bulkCreate(tenantId, items) {
        const results = {
            success: 0,
            failed: 0,
            errors: []
        };
        // Map category names from user's format to database format
        const categoryMap = {
            'Services': 'SERVICE',
            'Injection Moulding': 'COMPONENT',
            'Machining': 'COMPONENT',
            'Raw Material': 'RAW_MATERIAL',
            'Products': 'FINISHED_GOODS',
            'Sub Assemblies': 'SUBASSEMBLY',
            'Consumables': 'CONSUMABLE',
            'Packing Material': 'PACKING_MATERIAL',
            'Spare Parts': 'SPARE_PART'
        };
        for(let i = 0; i < items.length; i++){
            const item = items[i];
            try {
                // Map Excel column names to database fields - support multiple formats
                const rawCode = item['Item Code'] || item.code || item.Code || item.CODE || item['Item code'] || item['item code'];
                const rawName = item['Item Name'] || item.name || item.Name || item.NAME || item['Item name'] || item['item name'];
                const rawCategory = item['Item Group'] || item.category || item.Category || item.CATEGORY || item['Item group'] || item['item group'];
                const rawUom = item['Default Unit of Measure'] || item.uom || item.UOM || item.unit || item.Unit || item['Unit of Measure'];
                const rawHsn = item['HSN/SAC'] || item.hsn || item.HSN || item.hsn_code || item['HSN Code'];
                // Validate HSN code (must be 4, 6, or 8 digits)
                let validatedHsn = null;
                if (rawHsn) {
                    const hsnStr = String(rawHsn).trim();
                    if (/^\d{4}$|^\d{6}$|^\d{8}$/.test(hsnStr)) {
                        validatedHsn = hsnStr;
                    } else {
                        console.warn(`Invalid HSN code for row ${i + 1}: ${hsnStr}. Must be 4, 6, or 8 digits.`);
                    }
                }
                // Map category to database format
                let mappedCategory = categoryMap[rawCategory] || rawCategory || 'RAW_MATERIAL';
                // If still not a valid category, default to RAW_MATERIAL
                if (![
                    'RAW_MATERIAL',
                    'COMPONENT',
                    'SUBASSEMBLY',
                    'FINISHED_GOODS',
                    'CONSUMABLE',
                    'PACKING_MATERIAL',
                    'SPARE_PART',
                    'SERVICE'
                ].includes(mappedCategory)) {
                    mappedCategory = 'RAW_MATERIAL';
                }
                const itemData = {
                    code: rawCode,
                    name: rawName || rawCode,
                    description: item.description || item.Description || item.DESCRIPTION || '',
                    category: mappedCategory,
                    uom: rawUom || 'PCS',
                    standard_cost: parseFloat(item.standard_cost || item.StandardCost || item.cost || item.Cost || 0),
                    selling_price: parseFloat(item.selling_price || item.SellingPrice || item.price || item.Price || 0),
                    reorder_level: parseInt(item.reorder_level || item.ReorderLevel || item.min_qty || 0),
                    reorder_quantity: parseInt(item.reorder_quantity || item.ReorderQuantity || item.order_qty || 0),
                    lead_time_days: parseInt(item.lead_time_days || item.LeadTimeDays || item.lead_time || 0)
                };
                const { error } = await this.supabase.from('items').insert({
                    tenant_id: tenantId,
                    code: itemData.code,
                    name: itemData.name,
                    description: itemData.description,
                    category: itemData.category,
                    uom: itemData.uom,
                    standard_cost: itemData.standard_cost,
                    selling_price: itemData.selling_price,
                    reorder_level: itemData.reorder_level,
                    reorder_quantity: itemData.reorder_quantity,
                    lead_time_days: itemData.lead_time_days,
                    hsn_code: validatedHsn,
                    is_active: true,
                    metadata: {
                        item_group: rawCategory || null
                    }
                });
                if (error) {
                    results.failed++;
                    results.errors.push({
                        row: i + 1,
                        item: itemData.name || itemData.code,
                        error: error.message
                    });
                } else {
                    results.success++;
                }
            } catch (err) {
                results.failed++;
                results.errors.push({
                    row: i + 1,
                    item: item.name || item.code || 'Unknown',
                    error: err.message
                });
            }
        }
        return results;
    }
    async update(tenantId, id, itemData) {
        // Validate HSN code if provided
        let validatedHsn = null;
        if (itemData.hsnCode || itemData.hsn_code) {
            const hsnStr = String(itemData.hsnCode || itemData.hsn_code).trim();
            if (/^\d{4}$|^\d{6}$|^\d{8}$/.test(hsnStr)) {
                validatedHsn = hsnStr;
            }
        }
        const updateData = {
            updated_at: new Date().toISOString()
        };
        // Only update fields that are provided
        if (itemData.code !== undefined) updateData.code = itemData.code;
        if (itemData.name !== undefined) updateData.name = itemData.name;
        if (itemData.description !== undefined) updateData.description = itemData.description;
        if (itemData.category !== undefined) updateData.category = itemData.category;
        if (itemData.uom !== undefined) updateData.uom = itemData.uom;
        if (itemData.reorderLevel !== undefined) updateData.reorder_level = itemData.reorderLevel;
        if (itemData.minStock !== undefined) updateData.min_stock = itemData.minStock;
        if (itemData.maxStock !== undefined) updateData.max_stock = itemData.maxStock;
        if (itemData.standardCost !== undefined) updateData.standard_cost = itemData.standardCost;
        if (itemData.metadata !== undefined) updateData.metadata = itemData.metadata;
        if (validatedHsn !== null) updateData.hsn_code = validatedHsn;
        if (itemData.is_active !== undefined) updateData.is_active = itemData.is_active;
        const { data, error } = await this.supabase.from('items').update(updateData).eq('tenant_id', tenantId).eq('id', id).select().single();
        if (error) {
            throw new Error(`Failed to update item: ${error.message}`);
        }
        return data;
    }
    async delete(tenantId, id) {
        // Soft delete
        const { error } = await this.supabase.from('items').update({
            is_active: false
        }).eq('tenant_id', tenantId).eq('id', id);
        if (error) {
            throw new Error(`Failed to delete item: ${error.message}`);
        }
        return {
            message: 'Item deleted successfully'
        };
    }
    // Drawing/Document Management
    async getDrawings(tenantId, itemId) {
        const { data, error } = await this.supabase.from('item_drawings').select('*').eq('tenant_id', tenantId).eq('item_id', itemId).order('version', {
            ascending: false
        });
        if (error) {
            throw new Error(`Failed to fetch drawings: ${error.message}`);
        }
        return data || [];
    }
    async uploadDrawing(tenantId, userId, itemId, drawingData) {
        // Get current max version for this item
        const { data: existingDrawings } = await this.supabase.from('item_drawings').select('version').eq('tenant_id', tenantId).eq('item_id', itemId).order('version', {
            ascending: false
        }).limit(1);
        const nextVersion = existingDrawings && existingDrawings.length > 0 ? existingDrawings[0].version + 1 : 1;
        const { data, error } = await this.supabase.from('item_drawings').insert({
            tenant_id: tenantId,
            item_id: itemId,
            file_name: drawingData.fileName,
            file_url: drawingData.fileUrl,
            file_type: drawingData.fileType,
            file_size: drawingData.fileSize,
            version: nextVersion,
            revision_notes: drawingData.revisionNotes,
            is_active: true,
            uploaded_by: userId
        }).select().single();
        if (error) {
            throw new Error(`Failed to upload drawing: ${error.message}`);
        }
        return data;
    }
    async updateDrawing(tenantId, itemId, drawingId, drawingData) {
        const { data, error } = await this.supabase.from('item_drawings').update({
            revision_notes: drawingData.revisionNotes,
            is_active: drawingData.isActive,
            updated_at: new Date().toISOString()
        }).eq('tenant_id', tenantId).eq('item_id', itemId).eq('id', drawingId).select().single();
        if (error) {
            throw new Error(`Failed to update drawing: ${error.message}`);
        }
        return data;
    }
    async deleteDrawing(tenantId, itemId, drawingId) {
        const { error } = await this.supabase.from('item_drawings').update({
            is_active: false
        }).eq('tenant_id', tenantId).eq('item_id', itemId).eq('id', drawingId);
        if (error) {
            throw new Error(`Failed to delete drawing: ${error.message}`);
        }
        return {
            message: 'Drawing deleted successfully'
        };
    }
    constructor(){
        this.supabase = (0, _supabasejs.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
    }
};
ItemsService = _ts_decorate([
    (0, _common.Injectable)()
], ItemsService);

//# sourceMappingURL=items.service.js.map