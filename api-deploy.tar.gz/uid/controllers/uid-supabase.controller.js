"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "UidSupabaseController", {
    enumerable: true,
    get: function() {
        return UidSupabaseController;
    }
});
const _common = require("@nestjs/common");
const _uidsupabaseservice = require("../services/uid-supabase.service");
const _jwtauthguard = require("../../auth/guards/jwt-auth.guard");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let UidSupabaseController = class UidSupabaseController {
    create(req, createDto) {
        return this.uidService.createUID(req, createDto);
    }
    findAll(req, filters) {
        return this.uidService.findAll(req, filters);
    }
    searchUID(req, uid) {
        return this.uidService.searchUID(req, uid);
    }
    getHierarchy(req, uid) {
        return this.uidService.getUIDWithHierarchy(req, uid);
    }
    getPurchaseTrail(req, uid) {
        return this.uidService.getPurchaseTrail(req, uid);
    }
    updateLifecycle(req, uid, body) {
        return this.uidService.updateLifecycle(req, uid, body.stage, body.location, body.reference);
    }
    linkUIDs(req, body) {
        return this.uidService.linkUIDs(req, body.parentUID, body.childUID);
    }
    updateStatus(req, uid, body) {
        return this.uidService.updateStatus(req, uid, body.status, body.location);
    }
    validateUID(uid) {
        const isValid = this.uidService.validateUIDFormat(uid);
        return {
            uid,
            isValid,
            message: isValid ? 'UID format is valid' : 'Invalid UID format'
        };
    }
    getCompleteTrace(req, uid) {
        return this.uidService.getCompleteTrace(req, uid);
    }
    constructor(uidService){
        this.uidService = uidService;
    }
};
_ts_decorate([
    (0, _common.Post)(),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], UidSupabaseController.prototype, "create", null);
_ts_decorate([
    (0, _common.Get)(),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Query)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], UidSupabaseController.prototype, "findAll", null);
_ts_decorate([
    (0, _common.Get)('search/:uid'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('uid')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], UidSupabaseController.prototype, "searchUID", null);
_ts_decorate([
    (0, _common.Get)(':uid/hierarchy'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('uid')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], UidSupabaseController.prototype, "getHierarchy", null);
_ts_decorate([
    (0, _common.Get)(':uid/purchase-trail'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('uid')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], UidSupabaseController.prototype, "getPurchaseTrail", null);
_ts_decorate([
    (0, _common.Post)(':uid/lifecycle'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('uid')),
    _ts_param(2, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], UidSupabaseController.prototype, "updateLifecycle", null);
_ts_decorate([
    (0, _common.Post)('link'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], UidSupabaseController.prototype, "linkUIDs", null);
_ts_decorate([
    (0, _common.Put)(':uid/status'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('uid')),
    _ts_param(2, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        Object
    ]),
    _ts_metadata("design:returntype", void 0)
], UidSupabaseController.prototype, "updateStatus", null);
_ts_decorate([
    (0, _common.Get)(':uid/validate'),
    _ts_param(0, (0, _common.Param)('uid')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], UidSupabaseController.prototype, "validateUID", null);
_ts_decorate([
    (0, _common.Get)('trace/:uid'),
    _ts_param(0, (0, _common.Request)()),
    _ts_param(1, (0, _common.Param)('uid')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", void 0)
], UidSupabaseController.prototype, "getCompleteTrace", null);
UidSupabaseController = _ts_decorate([
    (0, _common.Controller)('uid'),
    (0, _common.UseGuards)(_jwtauthguard.JwtAuthGuard),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _uidsupabaseservice.UidSupabaseService === "undefined" ? Object : _uidsupabaseservice.UidSupabaseService
    ])
], UidSupabaseController);

//# sourceMappingURL=uid-supabase.controller.js.map